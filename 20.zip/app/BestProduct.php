<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BestProduct extends Model
{
    protected $guarded = [];
}
