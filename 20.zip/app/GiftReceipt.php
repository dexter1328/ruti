<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GiftReceipt extends Model
{
    //
    protected $guarded = [];
}
