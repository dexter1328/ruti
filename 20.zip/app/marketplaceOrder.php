<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class marketplaceOrder extends Model
{
    protected $guarded = [];

}
