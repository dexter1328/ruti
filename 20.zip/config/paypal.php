<?php
return [
    'client_id' => 'AfsstBIb_AMOGGLNAlJKbVheugbdhh-E3KnwV2w5f9tFFK2L7tDInvrDXn9k6z_qFtTxzYLI3c_rYgIz',
	'secret' => 'EFE0n3DlvSa940Jx2BiA7YiK43ln1czZevsFbqz-IhfOP2sk8kdXkCe7Yfq-WTorbUYjKqQ7zXEXSEog',
    'settings' => array(
        'mode' => 'sandbox',
        'http.ConnectionTimeOut' => 1000,
        'log.LogEnabled' => true,
        'log.FileName' => storage_path() . '/logs/paypal.log',
        'log.LogLevel' => 'FINE'
    ),
];
