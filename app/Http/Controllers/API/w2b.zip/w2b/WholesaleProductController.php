<?php

namespace App\Http\Controllers\API\w2b;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class WholesaleProductController extends Controller
{
    public function sendResponse($result, $message='')
    {
        $response = [
            'success' => true,
            'data'    => $result,
            'message' => $message,
        ];

        // return response()->json($response, 200, []);
        return response()->json($response, 200, [], JSON_PRESERVE_ZERO_FRACTION);
        // return response()->json($response, 200, [], JSON_PRESERVE_ZERO_FRACTION | JSON_NUMERIC_CHECK);
        // return response()->json($response, 200, [], JSON_NUMERIC_CHECK);
        /*$json = json_encode( $response, JSON_PRESERVE_ZERO_FRACTION);
        $json = preg_replace( "/\"(\d+)\"/", '$1', $json );
        echo $json;exit();*/
    }
    public function index()
	{
        $products = DB::table('w2b_products')->get();
        return $this->sendResponse(['Wholesale2b' => $products], 'Wholesale2b Products list.');
    }
}
