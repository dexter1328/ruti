<?php

namespace App\Imports;

use Maatwebsite\Excel\Concerns\WithHeadingRow;

class ProductImport implements WithHeadingRow
{
}
