<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VendorStorePermission extends Model
{
    //
}
