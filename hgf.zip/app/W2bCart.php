<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class W2bCart extends Model
{
    //
    protected $guarded = [];
}
