<?php

Route::group(['middleware' => 'supplierChecklist'], function () {
});
