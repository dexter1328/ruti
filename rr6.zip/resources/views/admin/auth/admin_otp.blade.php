<center>
	 <img
                width="50%"
                height="250px"
                style="margin-left: 5%"
                {{-- src="{{ asset('public/wb/img/new_homepage/logo/logo.png') }}" --}}
                src="https://naturecheckout.com/public/wb/img/new_homepage/logo/logo.png"
                alt="Nature Checkout"
              />
</center>

<h1>Verify your login</h1>
<p>Below is your one time passcode</p>
<h3>{{$otp}}</h3>
<p>If you are having any issue with your account, please don't hesitate to contact us by replying to this mail.</p>
<p>Thanks! <br> Nature Checkout</p>
