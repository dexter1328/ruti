<h5>Cancel Order</h5>
{{$order->order_no}} has been cancelled.