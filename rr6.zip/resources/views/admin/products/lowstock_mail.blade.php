<h1>Lowstock Product</h1>
<a href="{{ route('products.edit', $product_id_email) }}">Edit</a>