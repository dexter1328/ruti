<!DOCTYPE html>
<html>
<head>
    <title>Nature Checkout</title>
</head>
<body>
    <h1>{{ $details['title'] }}</h1><br>
    <p>{{ $details['body'] }}</p><br>
<p>Thank you for your order.</p> <br>

<p>We are delighted to inform you that your order is almost on its way. You should receive an email with tracking information once it has shipped.</p> <br>

<p>We appreciate your business and are committed to providing you with the best possible service.</p> <br>

<p>Best Regards!</p> <br>
<p>Nature Checkout</p>

</body>
</html>
