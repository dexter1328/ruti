<center>
	<img src="{{ asset('public/wb/img/new_homepage/logo/logo.png') }}" alt="One Letter" width="193" height="43" border="0" style="border: none; display: block; -ms-interpolation-mode: bicubic;">
</center>

<p>Hi,</p>

<p>{{$name}}  has tried to login after work hours.</p>
<label>Your Credentials</label>
<br>
Nature Checkout Team

