@extends('supplier.layout.main')
@section('content')

<div class="container">
    <h3>success</h3>
</div>


@endsection
