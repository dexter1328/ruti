<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StoresVendor extends Model
{
    protected $fillable = ['vendor_id', 'store_id'];
}
