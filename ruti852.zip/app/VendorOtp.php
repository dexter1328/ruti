<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VendorOtp extends Model
{
    //
}
