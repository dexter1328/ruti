<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ArchiveCancelOrder extends Model
{
    //
}
