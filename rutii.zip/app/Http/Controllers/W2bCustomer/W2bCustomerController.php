<?php

namespace App\Http\Controllers\W2bCustomer;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class W2bCustomerController extends Controller
{
    //
}
