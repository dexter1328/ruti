<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WbWishlist extends Model
{
    //
    protected $guarded = [];
}
