<h4>Success Order</h4>
<table>
<tr>
	<td>Order No</td>
	<td>Vendor Id</td>
	<td>Status</td>
</tr>
<tr>
	<td>{{$orders->order_no}}</td>
	<td>{{$orders->vendor_id}}</td>
	<td>{{$orders->order_status}}</td>
</tr>

</table>