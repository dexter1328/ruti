<!DOCTYPE html>
<html>
<head>
    <title>Ruti Self Checkout</title>
</head>
<body>
    <h1>{{ $details['title'] }}</h1><br>
    <p>{{ $details['body'] }}</p><br>
<h3><a href="http://www.rutiselfcheckout.com/admin/w2b_products/orders">Please Go to Admin Panel to take actions.</a></h3> <br>



<p>Best Regards!</p> <br>
<p>Ruti Self Checkout</p>

</body>
</html>
