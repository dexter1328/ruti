<?php

Route::get('/home', 'Employee\EmployeeController@index')->name('employee.home');

/*Route::get('/home', function () {
    $users[] = Auth::user();
    $users[] = Auth::guard()->user();
    $users[] = Auth::guard('employee')->user();

    //dd($users);

    return view('employee.home');
})->name('home');*/

