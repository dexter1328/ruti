<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class W2bOrder extends Model
{
    //
    protected $guarded = [];
}
