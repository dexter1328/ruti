<style>
    .stay-open {display:block !important;}


    div#social-links {
                max-width: 400px;
            }
            div#social-links ul li {
                display: inline-block;
            }
            div#social-links ul li a {
                padding: 5px;
                border: 1px solid #ccc;
                margin: 1px;
                font-size: 30px;
                color: #222;
                background-color: #ccc;
            }

            
/** rating **/
div.star {
  display: inline-block;
}

input.star { display: none; }

label.star {
  float: right;
  padding: 10px;
  font-size: 20px;
  color:
#444;
  transition: all .2s;
}

input.star:checked ~ label.star:before {
  content: '\f005';
  font-family: FontAwesome;
  color:
#e74c3c;
  transition: all .25s;
}

input.star-5:checked ~ label.star:before {
  color:
#e74c3c;
  text-shadow: 0 0 5px
#7f8c8d;
}

input.star-1:checked ~ label.star:before { color:
#F62; }

label.star:hover { transform: rotate(-15deg) scale(1.3); }

label.star:before {
  content: '\f006';
  font-family: FontAwesome;
}


.horline > li:not(:last-child):after {
    content: " |";
}
.horline > li {
  font-weight: bold;
  color:
#ff7e1a;

}

.checked-star {
    color: orange;
}
/** end rating **/
</style>









<?php /**PATH C:\xampp\htdocs\work\ruti\resources\views/front_end/style1.blade.php ENDPATH**/ ?>