<?php $__env->startSection('content'); ?>

<?php if($order_items->isNotEmpty()): ?>
<?php   $fund=0; ?>
<?php $__currentLoopData = $order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php 
        $count = $key+1;
        $id =  $order_item->order_id;
        $date = $order_item->created_at;
        $type = $order_item->type;
        $status = $order_item->order_status;
        $fund+=$order_item->quantity*$order_item->price; 
        $first_name = $order_item->first_name;
        $last_name = $order_item->last_name;
        $email = $order_item->email;
        $mobile = $order_item->mobile;
        $store = $order_item->store;
        $gems_points = $order_item->gems_point;
        $coins_point = $order_item->coin_point;
        $promo_code = $order_item->promo_code;
    ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<style type="text/css">
    .media-body {
        flex: 0.3;
    }
</style>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header align-items-center">
                <div class="left"> 
                   <span>Order # <?php echo e($id); ?> Details</span>               
                </div>
                <input type="hidden" name="" id="order_id" value="<?php echo e($id); ?>">
            </div>
            <div class="card-body">
                <div class="order-details"> 
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <b>Customer:</b>
                                <span><?php echo e($first_name); ?> <?php echo e($last_name); ?></span>
                            </div>

                            <div class="form-group">
                                    <b>Mobile:</b>
                                    <span><?php echo e($mobile); ?></span>
                            </div>

                            <div class="form-group">
                                <b>Email:</b>
                                <span> <?php echo e($email); ?></span>
                            </div>

                             <div class="form-group">
                                <b>Store:</b>
                                <span><?php echo e($store); ?></span>
                            </div>
                            <div class="form-group">
                                <b>Order Date:</b>
                                <span><?php echo e($date); ?></span>
                            </div>

                             <div class="form-group">
                                <b>Type:</b>
                                <span><?php echo e($type); ?></span>
                            </div>
                            <div class="form-group">
                                <b>Status:</b>
                                <span><?php echo e($status); ?></span>
                            </div>
                           
                        </div> 

                        <div class="col-sm-6">
                            
                            <div class="form-group">
                                <b>Total items:</b>
                                <span> <?php echo e($count); ?></span>
                            </div>
                            <div class="form-group">
                                <b>Item Total:</b>
                                <span>$<?php echo e(number_format($order_item->item_total,2)); ?></span>
                            </div>
                            <div class="form-group">
                                <b>Tax:</b>
                                <span><?php if(!empty($order_item->tax)): ?>$<?php echo e($order_item->tax); ?><?php else: ?> $0 <?php endif; ?></span>
                            </div>
                            <?php if(!empty($order_item->reward_point)): ?>
                            <div class="form-group">
                                <b>Reward:</b>
                                <span>$<?php echo e($gems_points/$gem_setting->value + $coins_point/$coin_setting->value); ?></span>
                                <!-- <span><?php echo e($order_item->reward_point); ?></span> -->
                            </div>
                            <?php endif; ?>
                            <?php if(!empty($promo_code)): ?>
                                <div class="form-group">
                                    <b>Promo Code:</b>
                                    <span><?php if(!empty($promo_code)): ?>$<?php echo e($promo_code); ?><?php else: ?> $0 <?php endif; ?></span>
                                </div>
                            <?php endif; ?>
                            <div class="form-group">
                                <b>Total amount:</b>
                                <span> $<?php echo e(number_format($order_item->total_price,2)); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <table id="example" class="table table-bordered order-detail-table" width="100%">
                    <thead>
                        <tr>
                            <th width="15%">Image</th>
                            <th width="55%">Items</th>
                            <th width="10%">Cost</th>
                            <th width="10%">Qty</th>
                            <th width="10%">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <?php if($order_item->image): ?>
                                    <td><img src="<?php echo e(asset('public/images/product_images').'/'.$order_item->image); ?>" width="50" height="50" class="customer-img rounded-circle"></td>
                                <?php else: ?>
                                    <td><img src="<?php echo e(asset('public/images/no-image.jpg')); ?>" width="50" height="50"></td>
                                <?php endif; ?>
                                <td><?php echo e($order_item->title); ?></td>
                                <td> $<?php echo e($order_item->price); ?></td>
                                <td><?php echo e($order_item->quantity); ?></td>
                                <td>$<?php echo e(number_format($order_item->quantity*$order_item->price,2)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <tr align="right">
                            <td colspan="5">
                                Total: <b>$<?php echo e(number_format($fund,2)); ?></b>
                            </td>
                        </tr>
                    </tbody>
                </table> 
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\work\ruti\resources\views/admin/orders/show.blade.php ENDPATH**/ ?>