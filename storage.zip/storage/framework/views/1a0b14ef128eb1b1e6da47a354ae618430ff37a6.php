<?php $__env->startSection('content'); ?>

<?php if(session()->get('success')): ?>
	<div class="alert alert-success alert-dismissible" role="alert">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<div class="alert-icon">
			<i class="fa fa-check"></i>
		</div>
		<div class="alert-message">
			<span><strong>Success!</strong> <?php echo e(session()->get('success')); ?></span>
		</div>
	</div>
<?php endif; ?>

<div class="row">
	<div class="col-lg-12">
		<div class="card">
			<div class="card-header">
				<div class="left"><span>Reviews</span></div>
				<div class="float-sm-right">
					<a style="padding-bottom: 3px; padding-top: 4px;" href="<?php echo e(route('supplier.product_reviews.create')); ?>" class="btn btn-outline-primary btn-sm waves-effect waves-light m-1" title="Add Review">
						<span class="name">Add Review</span>
					</a>
				</div>
			</div>
			<div class="card-body">
				<div class="table-responsive">
					<table id="example" class="table table-bordered">
						<thead>
							<tr>
								<th>#</th>
								<th>Product</th>
								<th>Customer</th>
								<th>Comment</th>
								<th>Rating</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $product_reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $product_review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($key+1); ?></td>
									<td><?php echo e($product_review->product); ?></td>
									<td><?php echo e($product_review->first_name); ?></td>
									<td><?php echo e($product_review->comment); ?></td>
									<td><?php echo e($product_review->rating); ?></td>
									<td class="action">
									    <form id="deletefrm_<?php echo e($product_review->id); ?>" action="<?php echo e(route('supplier.product_reviews.destroy', $product_review->id)); ?>" method="POST" class="delete"  onsubmit="return confirm('Are you sure?');"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?> </form><a href="javascript:void(0);" onclick="deleteRow('<?php echo e($product_review->id); ?>')" data-toggle="tooltip" data-placement="bottom" title="Delete Review"><i class="icon-trash icons"></i></a>
									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
						<tfoot>
							<tr>
								<th>#</th>
								<th>Product</th>
								<th>Customer</th>
								<th>Comment</th>
								<th>Rating</th>
								<th>Action</th>
							</tr>
						</tfoot>
					</table>
				</div>
			</div>
		</div>
	</div>
</div><!-- End Row-->
<script>
$(document).ready(function() {
	var table = $('#example').DataTable( {
		lengthChange: false,
				buttons: [
			{
				extend: 'copy',
				title: 'Review List',
				exportOptions: {
				columns: [ 0, 1,2,3,4]
				}
			},
			{
				extend: 'excelHtml5',
				title: 'Review List',
				exportOptions: {
				columns: [ 0, 1, 2,3,4]
				}
			},
			{
				extend: 'pdfHtml5',
				title: 'Review List',
				exportOptions: {
				columns: [ 0, 1, 2,3,4]
				}
			},
			{
				extend: 'print',
				title: 'Review List',
				autoPrint: true,
				exportOptions: {
				columns: [ 0, 1, 2,3,4]
				}
			},
			'colvis'
		],
		columnDefs: [
			{ "orderable": false, "targets": 5 }
		]
	});
	table.buttons().container()
	.appendTo( '#example_wrapper .col-md-6:eq(0)' );
});

function deleteRow(id)
{
	$('#deletefrm_'+id).submit();
}
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('supplier.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\work\ruti\resources\views/supplier/products_reviews/index.blade.php ENDPATH**/ ?>