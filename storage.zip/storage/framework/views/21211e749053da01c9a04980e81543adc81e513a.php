<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"> 
<title>RUTI Self Checkout | One-Stop E-commerce hub for online selling, in-store buying and self-checkout.</title>
<meta name="description" content="RUTI self checkout, a free mobile app that provides safe and convenient grocery shopping during post pandemic- Smart grocery app - Free delivery RUTI self checkout - buy groceries online – grocery stores online services"> 
<meta name="keywords" content="Smart grocery app store near me, Free delivery RUTI self checkout, Closest store near me RUTI self checkout, Shop groceries stores online, Mobile app for grocery shopping, Smart in-store shopping app, Get online coupon from RUTI self checkout, Scan and go mobile app from RUTI self checkout, Smart way to buy and sell online from RUTI self checkout, Smart and convenient shopping mobile app from RUTI self checkout, Best way to sell, Sell online, Online sells, Online seller, E-commerce selling, Ecommerce sells, Sales hub, Where to sell, Sell on instacart, Sell on Etsy, Sell on Amazon, Best place to sell, Where to sell, Best Buy and sell center "> 
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"> -->
<!-- <meta http-equiv="Content-type" content="text/html; charset=UTF-8"> -->
<meta name="theme-color" content="#003366" />
<meta property="og:title" content="<?php echo e(config('app.name', 'RUTI self checkout')); ?>" />
<meta property="og:description" content="We provide convenient and expeditious service to all users (merchants and consumers) in areas of consumer spending. Our service is to improve merchant - customer relations while offering positive contribution to the overall economy." />
<meta property="og:image" content="<?php echo e(asset('public/images/logo-icon.png')); ?>" />
<meta property="og:type" content="website" />
<meta property="og:url" content="https://rutiselfcheckout.com/" />
<meta property="fb:app_id" content="482623692719207" />
<style>
/*/    .dropbtn {
        background-color: #003366;
        color: #fff;
        padding: 7px 20px;
        font-size: 16px;
        border: none;
        border-radius: 5px;
}*/
.dropbtn {
    background-color: #003366;
    color: #fff;
    padding: 7px 20px;
    font-size: 16px;
    border: none;
    border-radius: 5px;
    position: relative;
    padding-right: 44px;
}
.dropbtn .sign-down {
    font-size: 20px;
    position: fixed;
    margin: 5px 10px;
}
/*.dropdown .dropbtn:hover .sign-down:before{
    content: '\f106';
    transition: all 0.3s ease;

}*/
.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 175px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
  border-radius: 5px;
  margin-left: -147px;
  padding: 10px;
  padding-bottom: 15px;
}
.dropdown-content-caret{
    content: '';
    top: calc(100% + -22.5rem);
    background-color: #f1f1f1;
    border-top-left-radius: 0.25rem;
    width: 1rem;
    height: 1rem;
    border-top: 1px solid #aab7c2;
    border-left: 1px solid #aab7c2;
    border-bottom-color: transparent;
    transform: rotateZ(45deg);
    position: absolute;
    z-index: 1061;
    right: 20px;
}
.dropdown-box{
    border-bottom: 1px solid #aba2a2;
    padding-bottom: 10px;
}
.dropdown-box2{
    margin-top: 8px;
}
.dropdown-content .common-link:hover{
    text-decoration: underline;
}
.dropdown-content .common-link
{
    color: #09757a!important; 
} 


.dropdown-content a {
  color: #000!important;
  padding: 12px 16px!important;
  text-decoration: none;
  display: block!important;
  padding: 4px 10px !important; text-align: left !important;
}

/*.dropdown-content a:hover {background-color: #ddd;}*/

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #003366;}

.fa.fa-tiktok {
    background: url("<?php echo e(asset('public/frontend/image/tiktok-white.png')); ?>") no-repeat;
    width: 22px;
    height: 25px;
}
.follow a:hover .fa.fa-tiktok {
    background: url("<?php echo e(asset('public/frontend/image/tiktok-blue.png')); ?>") no-repeat;
    width: 22px;
    height: 25px;
}
</style>

<link rel="icon" href="<?php echo e(asset('public/images/favicon-32x32.png')); ?>" type="image/x-icon">
<!---Font Icon-->
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

<!-- Plugin CSS -->
<link href="<?php echo e(asset('public/frontend/css/bootstrap.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('public/frontend/css/slick.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('public/frontend/css/jquery.css')); ?>" rel="stylesheet">
 <link href="<?php echo e(asset('public/frontend/css/animate.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('public/frontend/css/magnific-popup.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('public/frontend/css/YouTubePopUp.css')); ?>" rel="stylesheet">

<!-- Theme Style -->
<link href="<?php echo e(asset('public/frontend/css/style.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('public/frontend/css/responsive.css')); ?>" rel="stylesheet">
<?php if(Request::path() == '/'): ?>
    <style>
        .navbar {
            position: fixed;
            width: 100%;
            padding-top: 12px;
            padding-bottom: 12px;
            transition: all linear .3s;
        }
    </style>
<?php else: ?>
	<style>
		
		.navbar{
			background: linear-gradient(to right, rgba(0,51,102,1) 0%, rgba(236,103,36,1) 100%);
		}
        /*.dropdown{
            top:17px;
        }*/
		/*.header-nav .m-nav {
		    margin-right: 0;
		    margin-top: -20px;
		}*/
		#inner-main-content {
		    position: relative;
		    width: 100%;
		    /*padding: 135px 0;*/
		}
	</style>
<?php endif; ?>

    <!-- jQuery -->
    <script src="<?php echo e(asset('public/frontend/js/jquery-3.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontend/js/jquery-migrate-3.js')); ?>"></script>

    <!-- Plugins -->
    <script src="<?php echo e(asset('public/frontend/js/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontend/js/slick.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontend/js/counter.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontend/js/waypoints.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontend/js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontend/js/YouTubePopUp.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontend/js/SmoothScroll.js')); ?>"></script>
    <!-- custom -->
    <script src="<?php echo e(asset('public/frontend/js/custom.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontend/js/preloader.js')); ?>"></script>

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-189301985-1"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'UA-189301985-1');
    </script>

    <!-- Global site tag (gtag.js) - Google Ads: 978318545 -->
    <script async src=https://www.googletagmanager.com/gtag/js?id=AW-978318545></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
     

      gtag('config', 'AW-978318545');
    </script>

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-JNHSLQJ5TS"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'G-JNHSLQJ5TS');
    </script>    

    <!-- Start of HubSpot Embed Code -->
    <script id="hs-script-loader" async defer src="//js.hs-scripts.com/22066612.js"></script>
    <!-- End of HubSpot Embed Code -->

    <script>
        function geoFindMe() {

            /*const status = document.querySelector('#status');
            const mapLink = document.querySelector('#map-link');

            mapLink.href = '';
            mapLink.textContent = '';*/

            function success(position) {
                const latitude  = position.coords.latitude;
                const longitude = position.coords.longitude;

                /*status.textContent = '';
                mapLink.href = `https://www.openstreetmap.org/#map=18/${latitude}/${longitude}`;
                mapLink.textContent = `Latitude: ${latitude} °, Longitude: ${longitude} °`;*/
            }

            function error() {
                // status.textContent = 'Unable to retrieve your location';
            }

            if(!navigator.geolocation) {
                // status.textContent = 'Geolocation is not supported by your browser';
            } else {
                // status.textContent = 'Locating…';
                navigator.geolocation.getCurrentPosition(success, error);
            }
        }
        geoFindMe();
    </script>

    <?php if(request()->is('vendor-signup')): ?>
    <!-- Global site tag (gtag.js) - Google Ads: 978318545 --> 
    <script async src="https://www.googletagmanager.com/gtag/js?id=AW-978318545"></script> 
    <script> window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'AW-978318545'); </script>
    <?php endif; ?>

    <?php if(request()->is('thank-you')): ?>
    <!-- Event snippet for Sign-up conversion page --> 
    <script> gtag('event', 'conversion', {'send_to': 'AW-978318545/cm4ECOHUtKEDENHpv9ID'}); </script>
    <?php endif; ?>
    
     <?php if(request()->is('read-first') || request()->is('vendor-signup')): ?>
    <!-- Support Widget -->
    <script type="text/javascript">
    window.Trengo = window.Trengo || {};
    window.Trengo.key = 'oxmtCRRS03uVdb6mASWz';
    (function(d, script, t) {
    script = d.createElement('script');
    script.type = 'text/javascript';
    script.async = true;
    script.src = 'https://static.widget.trengo.eu/embed.js';
    d.getElementsByTagName('head')[0].appendChild(script);
    }(document));

    $(document).ready(function () {
        $('.back-top-btn').css('right', '90px');
    })
    </script>
    <?php endif; ?>
</head>

<body data-spy="scroll" data-target="#nav-part" data-offset="90">
	<!-- back to top start -->
    <a href="#" class="back-top-btn"><i class="fa fa-angle-double-up"></i></a>
    <!-- back to top end -->

    <!-- Loading -->
    <div id="musa-loader" style="display: none;">
        <div id="loading-center">
            <div id="loading-center-absolute">
                <img src="<?php echo e(asset('public/frontend/image/animat-rocket.gif')); ?>" alt="">
            </div>
        </div>
    </div>
    <!-- Header -->
    <header>
        <nav class="navbar header-nav other-nav custom_nav sticky-top navbar-expand-md">
            <div class="container p-0">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('public/frontend/image/logo.png')); ?>" class="img-fluid" alt="logo"></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
                    <ul class="navbar-nav m-nav">
                        <li class="nav-item"><a class="nav-link active" href="<?php echo e(url('/')); ?>">Home</a></li>
	                    <li class="nav-item"><a class="nav-link active" href="<?php echo e(url('/')); ?>/#aboutus">About Us</a></li>
	                    <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/')); ?>/#vendors">Vendors</a></li>
	                    <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/')); ?>/#features">Features</a></li>
	                    <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/')); ?>/#download">Download</a></li>
	                    <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/')); ?>/#news11">Offers</a></li>
                        <li class="nav-item">
                            <div class="dropdown">
                                <button class="dropbtn">Vendor Sign In <i class="sign-down fa fa-angle-down"></i></button>
                                <div class="dropdown-content">
                                    <div class="dropdown-content-caret"></div>
                                   <!--  <a href="<?php echo e(url('/read-first')); ?>">Register</a>
                                    <a href="<?php echo e(url('/vendor/login')); ?>">Login</a> -->
                                    <div class="dropdown-box">
                                        <a><b>Registered Users</b></a>
                                        <a>Have an account? Sign in now.</a>
                                        <a href="<?php echo e(url('/vendor/login')); ?>" class="common-link">Sign in</a>
                                   </div>
                                   <div class="dropdown-box">
                                        <a><b>New Customer</b></a>
                                        <a>New to RUTI self checkout? Create an account to get started today.</a>
                                        <a href="<?php echo e(url('/read-first')); ?>" class="common-link">Create Account</a>
                                    </div>
                                    <div class="dropdown-box2">
                                        <a>Registration on this page is only for businesses. For customer, Scan QR code to install application.</a>
                                    </div>
                                </div>
                            </div>
                        </li>
                        
                	</ul>
                </div>
            </div>
        </nav>
    </header>
    <!-- Header End -->
    <div class="clearfix"></div>
	<div class="content-wrapper">
		<?php echo $__env->yieldContent('content'); ?>
	</div>
 <!-- Contact Start -->
    <section id="news11">
        <div class="container">
            <div class="row">
                <div class="newsletter">
                    <div class="col-lg-12 m-auto">
                        <div class="row">
                            <div class="col-lg-12 text-center">
                                <div class="news">
                                    <h2>Get Updates &amp; Special Offers</h2>
                                </div>
                            </div>
                            <div class="col-12 text-center">
                                <div class="name name-or">
                                    <a href="#" data-toggle="modal" data-target="#exampleModal5">Sign Up for Newsletter</a>
                                </div>
                            </div>
                            
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

    <section id="contact" class="contact-section">
        <div class="container">
            <div class="row contact-text">
                <div class="offset-md-3 col-md-6 contact-logo text-center">
                    <h1>
                        <?php echo e(isset($page_meta['footer_title']) && $page_meta['footer_title']!='' ? $page_meta['footer_title'] : 'RUTI self checkout'); ?>

                    </h1>
                    <?php if(isset($page_meta['footer_description']) && $page_meta['footer_description']!=''): ?>
                        <p><?php echo $page_meta['footer_description']; ?></p>
                    <?php else: ?>
                        <p>We provide  convenient  and  expeditious  service  to  all  users  (merchants  and consumers) in areas of consumer spending. Our service is to improve merchant - customer relations while offering positive contribution to the overall economy.</p>
                    <?php endif; ?>
                </div>
                <div class="col-sm-12">
                    <div class="row">
                        <div class="footer_address">
                            <ul>
                                <li>829 W Palmdale Blvd, Suite 133 Palmdale, California 93551</li>
                                <li>We are here to help, contact us</li>
                                <?php /* ?>
                                <li><a href="tel:1.800.210.2694">1.800.210.2694</a></li>
                                <?php */ ?>
                                <li><a href="mail:info@rutiselfcheckout.com">info@rutiselfcheckout.com</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-sm-12">
                    <div class="row">
                        <div class="follow mx-auto">
                            <a href="<?php echo e(isset($page_meta['footer_facebook_link']) && $page_meta['footer_facebook_link']!='' ? $page_meta['footer_facebook_link'] : 'https://www.facebook.com/ezsiop.ezsiop.1'); ?>" target="_blank"><i class="fa fa-facebook"></i> </a>

                            <a href="<?php echo e(isset($page_meta['footer_twitter_link']) && $page_meta['footer_twitter_link']!='' ? $page_meta['footer_twitter_link'] : 'https://mobile.twitter.com/ezsiop'); ?>" target="_blank"><i class="fa fa-twitter"></i> </a>
                            
                            <a href="<?php echo e(isset($page_meta['footer_linkedin_link']) && $page_meta['footer_linkedin_link']!='' ? $page_meta['footer_linkedin_link'] : 'https://www.linkedin.com/in/ezsiop-ezsiop-b54199204/'); ?>" target="_blank"><i class="fa fa-linkedin"></i> </a>

                            <a href="<?php echo e(isset($page_meta['footer_instagram_link']) && $page_meta['footer_instagram_link']!='' ? $page_meta['footer_instagram_link'] : 'https://www.instagram.com/ezsiop/'); ?>" target="_blank"><i class="fa fa-instagram"></i> </a>

                            <a href="<?php echo e(isset($page_meta['footer_pinterest_link']) && $page_meta['footer_pinterest_link']!='' ? $page_meta['footer_pinterest_link'] : 'https://www.pinterest.com/Ezsiop'); ?>" target="_blank"><i class="fa fa-pinterest"></i> </a>

                            <a href="<?php echo e(isset($page_meta['footer_tiktok_link']) && $page_meta['footer_tiktok_link']!='' ? $page_meta['footer_tiktok_link'] : 'https://tiktok.com/@ezsiop_'); ?>" target="_blank" class="pt-1"><i class="fa fa-tiktok"></i> </a>
                            <!-- <a href="<?php echo e(isset($page_meta['footer_tiktok_link']) && $page_meta['footer_tiktok_link']!='' ? $page_meta['footer_tiktok_link'] : 'https://tiktok.com/@ezsiop_'); ?>" target="_blank"><img src="<?php echo e(asset('public/frontend/image/icons8-tiktok-30.png')); ?>" style="margin-bottom: 5px;"> </a> -->
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="copyrights">
                    <div class="left">
                        <!-- <div class="footer-inner">EZSIOP INC &copy; 2019-2024. All Rights Reserved</div> -->
                        <div class="footer-inner">RUTI self checkout &copy; 2019-2024. All Rights Reserved</div>
                    </div>
                    <div class="right">
                        <ul class="footer-link">
                            <?php /* ?> 
                            <li><a class="nav-link active" href="<?php echo e(url('/dmca')); ?>">DMCA</a></li>
                            <?php */ ?>
                            <?php /* ?>
                            <li><a class="nav-link" href="http://ezsiop.com/return-policy">Refund Policy</a></li>
                            <?php */ ?>
                            <li><a class="nav-link" href="<?php echo e(url('/terms-condition')); ?>">Terms &amp; Conditions</a></li>
                            <li><a class="nav-link" href="<?php echo e(url('/privacy-policy')); ?>">Privacy Policy</a></li>
                        </ul>
                    </div>
                    <div class="clearfix"></div>
                </div> 
            </div>
        </div>
    </section>
    <!-- Contact End -->
    <!-- Main End -->

    <!-- Newsletter popup start -->
    <div class="col-12">
        <div class="row">
            <div class="modal fade" id="exampleModal5" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <!-- <h5 class="modal-title" id="exampleModalLabel08"></h5> -->
                            <a href="#" class="download-close" data-dismiss="modal" aria-label="Close"><i class="fa fa-close"></i></a>
                        </div>
                        <div id="letter5" class="">

                            <div class="letter_inner">
                                <img src="<?php echo e(asset('public/frontend/image/logo-tagline.png')); ?>" class="img-fluid" alt="">
                                <h2>Sign Up For Newsletter</h2>
                                <p>If you sign up for our newsletter, you will never miss a single news or updates from our website. So, Don’t waste any time. Sign up now!</p>
                            </div>
                            <div class="mainButton">
	                            <div class="input-group">
	                                <input type="email" name="email" id="email" class="form-controls" placeholder="Your E-mail Here">
	                                <span class="input-group-btn">
	                         			<button class="button btn-default" id="subscribe_btn">Subscribe</button>
	                                 </span>
	                            </div>
                        	</div>
                            <div style="text-align: center;">
                                <span class="text-danger" id="email_error"></span>
                                <span class="text-danger" id="subscribe_success"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Newsletter popup end -->

    <script>

		$("#subscribe_btn").click(function(){
			var email = $("#email").val();
			if(email != ''){
				$.ajax({
					
					url: "<?php echo e(url('/subscribe_newsletter')); ?>/"+email,
					type: "GET",
					dataType: 'json',
					success: function (data) {
						if(data.error != ''){
							$("#subscribe_success").html(data.error);
						}
						if(data.success != ''){
							$("#subscribe_success").html(data.success);
						}
					},
					error: function (data) {
					}
				});
			}else{
				$("#email_error").html('Please enter email.');
				$("#subscribe_success").html('');
			}
		});
	</script>  
	<script>
        $(document).ready(function(){
            // Add minus icon for collapse element which is open by default
            $(".collapse.show").each(function(){
                $(this).prev(".card-header").find(".fa").addClass("fa-minus").removeClass("fa-plus");
            });
            
            // Toggle plus minus icon on show hide of collapse element
            $(".collapse").on('show.bs.collapse', function(){
                $(this).prev(".card-header").find(".fa").removeClass("fa-plus").addClass("fa-minus");
            }).on('hide.bs.collapse', function(){
                $(this).prev(".card-header").find(".fa").removeClass("fa-minus").addClass("fa-plus");
            });
        });
    </script>  
    <script>
      window.addEventListener('load', function(){
        jQuery('button:contains("SignUp")').click(function(){
          gtag('event', 'conversion', {'send_to': 'AW-10934253752/EO76CLahpMsDELjx7d0o'});
        });
      });
    </script>
</body>
</html><?php /**PATH /home/gtvmcmgwqds4/public_html/resources/views/front_end/layout.blade.php ENDPATH**/ ?>