<?php $__env->startSection('content'); ?>

    
    <div style="clear:both;"></div>
    
    <!-- terms-condition start -->
    <section id="inner-main-content">
        <h4 class="heading" style="font-size: 33px !important;">Thank You For Choosing RUTI Self Checkout. Please check your email for further update.</h4>
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-10 col-offset-md-1">
                    <div class="font-para">
                        <p></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
   <?php $__env->stopSection(); ?>
<?php echo $__env->make('front_end.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gtvmcmgwqds4/public_html/resources/views/thankyou.blade.php ENDPATH**/ ?>