<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <div class="left"><span>Header</span></div>
            </div>
            <div class="card-body">
            	<div class="container-fluid">
                    <?php if(session()->get('success')): ?>
                        <div class="alert alert-success alert-dismissible" role="alert">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <div class="alert-icon">
                                <i class="fa fa-check"></i>
                            </div>
                            <div class="alert-message">
                                <span><strong>Success!</strong> <?php echo e(session()->get('success')); ?></span>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div id="ajaxMsg"></div>
                    <form id="addFrm" method="post" action="<?php echo e(route('pagemeta.header')); ?>" enctype="multipart/form-data"> 
                        <?php echo csrf_field(); ?> 
                        <div class="form-group">
                            <label for="title">Title<span class="text-danger">*</span></label>
                            <textarea class="form-control" name="title" rows="5"><?php echo e(old('title', isset($header['header_title']) ? $header['header_title']: '')); ?></textarea>
                            <?php if($errors->has('title')): ?> 
                                <span class="text-danger"><?php echo e($errors->first('title')); ?></span> 
                            <?php endif; ?> 
                        </div>
                        <div class="form-group">
                            <label for="android_app_link">Android APP Link<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="android_app_link" value="<?php echo e(old('android_app_link', isset($header['header_android_app_link']) ? $header['header_android_app_link'] : '')); ?>"> 
                            <?php if($errors->has('android_app_link')): ?> 
                                <span class="text-danger"><?php echo e($errors->first('android_app_link')); ?></span> 
                            <?php endif; ?> 
                        </div>
                        <div class="form-group">
                            <label for="ios_app_link">IOS APP Link<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="ios_app_link" value="<?php echo e(old('ios_app_link', isset($header['header_ios_app_link']) ? $header['header_ios_app_link'] : '')); ?>"> 
                            <?php if($errors->has('ios_app_link')): ?> 
                                <span class="text-danger"><?php echo e($errors->first('ios_app_link')); ?></span> 
                            <?php endif; ?> 
                        </div>
                        <div class="form-group">
                            <label for="image">Image<span class="text-danger">*</span></label>
                            <input type="file" class="form-control" name="image">
                            <input type="hidden" name="exist_image" value="<?php echo e(isset($header['header_image']) ? $header['header_image'] : ''); ?>">
                            <?php if(isset($header['header_image']) && $header['header_image']!=''): ?>
                                <a href="<?php echo e(asset('public/images/pagemeta/'.$header['header_image'])); ?>" target="_blank">Click here</a> to view image <br>
                            <?php endif; ?>
                            <?php if($errors->has('image')): ?> 
                                <span class="text-danger"><?php echo e($errors->first('image')); ?></span> 
                            <?php endif; ?> 
                        </div>
                        <center>
                            <button type="submit" id="submitBtn" class="btn btn-success"><i class="fa fa-check-square-o"></i> SAVE</button>
                        </center>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('employee.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gtvmcmgwqds4/public_html/resources/views/employee/header.blade.php ENDPATH**/ ?>