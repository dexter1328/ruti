<?php $__env->startSection('content'); ?>
<?php if(session()->get('success')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
	<button type="button" class="close" data-dismiss="alert">×</button>
		<div class="alert-icon">
			<i class="fa fa-check"></i>
		</div>
		<div class="alert-message">
			<span><strong>Success!</strong> <?php echo e(session()->get('success')); ?></span>
		</div>
</div>
<?php endif; ?>
<?php if(session()->get('error')): ?>
<div class="alert alert-danger alert-dismissible" role="alert">
	<button type="button" class="close" data-dismiss="alert">×</button>
		<div class="alert-icon">
			<i class="fa fa-check"></i>
		</div>
		<div class="alert-message">
			<span><strong>Failed!</strong> <?php echo e(session()->get('success')); ?></span>
		</div>
</div>
<?php endif; ?>

<div class="row">
	<div class="col-lg-12">
		<div class="card">
			<div class="card-header"><div class="left"><span>Orders</span></div>
		</div>
		<div class="card-body">
			<div class="table-responsive">
				<table id="example" class="table table-bordered">
					<thead>
						<tr>
                            <th>#</th>
                            <th style="width: 15%">Order No</th>
                            <th style="width: 25%">Customer Name</th>
                            <th>Total Price</th>
                            <th>Is Paid</th>
                            <th>Status</th>
                            <th>Products</th>
                            <th>Actions</th>
                            <th>Details</th>
						</tr>
					</thead>
					<tbody>
                        <?php $__currentLoopData = $op; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($item->order_id); ?></td>
                            <td><?php echo e($item->user_name); ?></td>
                            <td><?php echo e($item->price); ?></td>
                            <td><?php echo e($item->is_paid); ?></td>
                            <td><?php echo e($item->status); ?></td>
                            <td><?php echo e($item->title); ?></td>
                            <td><a href="<?php echo e(route('supplier.supplier_shippo',['user_id'=>$item->user_id,'product_sku'=>$item->sku,'supplier_id'=>$item->supplier_id])); ?>" class="btn btn-info">Ship</a></td>
                            <td><a href="<?php echo e(route('supplier.orders.view_details', $item->order_id)); ?>" class="btn btn-info">Details</a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</tbody>
					<tfoot>
						<tr>
                            <th>#</th>
                            <th style="width: 15%">Order No</th>
                            <th style="width: 25%">Customer Name</th>
                            <th>Total Price</th>
                            <th>Is Paid</th>
                            <th>Status</th>
                            <th>Products</th>
                            <th>Actions</th>
                            <th>Details</th>
						</tr>
					</tfoot>
				</table>
			</div>
		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('supplier.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\work\ruti\resources\views/supplier/orders/index.blade.php ENDPATH**/ ?>