<script type="text/javascript">
    var route = "<?php echo e(url('/shop/search/autocomplete')); ?>";
    $('input.typeahead').typeahead({
        source:  function (query, process) {
      return $.get(route, { term: query }, function (data) {
              return process(data);
          });
      }
    },
      {
        hint: true,
        highlight: true,
        minLength: 1
        },
      );
</script><?php /**PATH C:\xampp\htdocs\work\ruti\resources\views/front_end/scripts2.blade.php ENDPATH**/ ?>