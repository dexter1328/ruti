<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-lg-12">
		<div class="card">
			<div class="card-header">
				<div class="left">
					<!-- <i class="fa fa-shopping-bag"></i> --><span>Edit Vendor Store</span>
				</div>
			</div>
			<div class="card-body">
            	<div class="container-fluid">
					<form id="signupForm" method="post" action="<?php echo e(route('vendor_store.update',$vendor_store->id)); ?>" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
					<?php echo method_field('PATCH'); ?>
					<div class="form-group row">
						<label for="input-10" class="col-sm-2 col-form-label">Vendor<span class="text-danger">*</span></label>
						<div class="col-sm-4">
							<select name="vendor_id" class="form-control">
								<option value="">Select Vendor</option>
								<?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($vendor->id); ?>"<?php echo e((old("vendor_id", $vendor_store->vendor_id) == $vendor->id ? "selected":"")); ?>><?php echo e($vendor->name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
							<?php if($errors->has('vendor_id')): ?>
								<span class="text-danger"><?php echo e($errors->first('vendor_id')); ?></span>
							<?php endif; ?>
						</div>
						<label for="input-11" class="col-sm-2 col-form-label">Name<span class="text-danger">*</span></label>
						<div class="col-sm-4">
							<input type="text"  class="form-control" name="name" value="<?php echo e(old('name',$vendor_store->name)); ?>">
							<?php if($errors->has('name')): ?>
								<span class="text-danger"><?php echo e($errors->first('name')); ?></span>
							<?php endif; ?>
						</div>
					</div>
					<div class="form-group row">
						<label for="input-12" class="col-sm-2 col-form-label">Email<span class="text-danger">*</span></label>
						<div class="col-sm-4">
							<input type="email" name="email" class="form-control" value="<?php echo e(old('email',$vendor_store->email)); ?>">
							<?php if($errors->has('email')): ?>
							<span class="text-danger"><?php echo e($errors->first('email')); ?></span>
							<?php endif; ?>
						</div>
						<label for="input-12" class="col-sm-2 col-form-label">Phone Number<span class="text-danger">*</span></label>
						<div class="col-sm-4">
							<input type="text" name="phone_number" class="form-control" value="<?php echo e(old('phone_number',$vendor_store->phone_number)); ?>">
							<?php if($errors->has('phone_number')): ?>
								<span class="text-danger"><?php echo e($errors->first('phone_number')); ?></span>
							<?php endif; ?>
						</div>
					</div>
					<div class="form-group row">
						<label for="input-12" class="col-sm-2 col-form-label">Manager Name<span class="text-danger">*</span></label>
						<div class="col-sm-4">
							<input type="text" name="manager_name" class="form-control" value="<?php echo e(old('manager_name',$vendor_store->manager_name)); ?>" placeholder="Enter Manager Name">
							<?php if($errors->has('manager_name')): ?>
								<span class="text-danger"><?php echo e($errors->first('manager_name')); ?></span>
							<?php endif; ?>
						</div>
						<label for="input-13" class="col-sm-2 col-form-label">No OF Staff<span class="text-danger">*</span></label>
						<div class="col-sm-4">
							<input type="number" name="no_of_staff" class="form-control" value="<?php echo e(old('no_of_staff',$vendor_store->no_of_staff)); ?>" placeholder="Enter No Of Staff">
							<?php if($errors->has('no_of_staff')): ?>
								<span class="text-danger"><?php echo e($errors->first('no_of_staff')); ?></span>
							<?php endif; ?>
						</div>
					</div>
					<div class="form-group row">
						<label for="input-13" class="col-sm-2 col-form-label">Mobile Number</label>
						<div class="col-sm-4">
							<input type="text" name="mobile_number" class="form-control" value="<?php echo e(old('mobile_number',$vendor_store->mobile_number)); ?>">
							<?php if($errors->has('mobile_number')): ?>
							<span class="text-danger"><?php echo e($errors->first('mobile_number')); ?></span>
							<?php endif; ?>
						</div>	
						<label for="input-12" class="col-sm-2 col-form-label">Branch Admin<span class="text-danger">*</span></label>
						<div class="col-sm-4">
							<input type="text" name="branch_admin" class="form-control" value="<?php echo e(old('branch_admin',$vendor_store->branch_admin)); ?>">
							<?php if($errors->has('branch_admin')): ?>
								<span class="text-danger"><?php echo e($errors->first('branch_admin')); ?></span>
							<?php endif; ?>
						</div>
					</div>
					<div class="form-group row">
						<label for="input-12" class="col-sm-2 col-form-label">Address<span class="text-danger">*</span></label>
						<div class="col-sm-4">
							<textarea class="form-control" id="input-8" name="address"><?php echo e($vendor_store->address1); ?>

							</textarea>
							<?php if($errors->has('address')): ?>
								<span class="text-danger"><?php echo e($errors->first('address')); ?></span>
							<?php endif; ?> 
						</div>
						<label for="input-13" class="col-sm-2 col-form-label">Country<span class="text-danger">*</span></label>
						<div class="col-sm-4">
							<select class="form-control" name="country" id="country">
								<option value="">Select Country</option>
								<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($country->id); ?>"<?php echo e((old("country", $vendor_store->country) == $country->id ? "selected":"")); ?>><?php echo e($country->name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
							<?php if($errors->has('country')): ?>
								<span class="text-danger"><?php echo e($errors->first('country')); ?></span>
							<?php endif; ?>
						</div>
					</div>
					<div class="form-group row">
						<label for="input-12" class="col-sm-2 col-form-label">State<span class="text-danger">*</span></label>
						<div class="col-sm-4">
							<select class="form-control" id="state" name="state" value="<?php echo e(old('state')); ?>">
								<option value="">Select State</option>
							</select>
							<?php if($errors->has('state')): ?>
								<span class="text-danger"><?php echo e($errors->first('state')); ?></span>
							<?php endif; ?>
						</div>
						<label for="input-13" class="col-sm-2 col-form-label">City<span class="text-danger">*</span></label>
						<div class="col-sm-4">
							<select class="form-control" id="city" name="city" value="<?php echo e(old('city')); ?>">
								<option value="">Select City</option>
							</select>
							<?php if($errors->has('city')): ?>
								<span class="text-danger"><?php echo e($errors->first('city')); ?></span>
							<?php endif; ?>
						</div>
					</div>
					<div class="form-group row">
						<label for="input-12" class="col-sm-2 col-form-label">Latitude<span class="text-danger">*</span></label>
						<div class="col-sm-4">
							<input type="text" name="lat" class="form-control" value="<?php echo e(old('lat',$vendor_store->lat)); ?>">
							<?php if($errors->has('lat')): ?>
								<span class="text-danger"><?php echo e($errors->first('lat')); ?></span>
							<?php endif; ?>
						</div>
						<label for="input-13" class="col-sm-2 col-form-label">Longitude<span class="text-danger">*</span></label>
						<div class="col-sm-4">
							<input type="text" name="long" class="form-control" value="<?php echo e(old('long',$vendor_store->long)); ?>">
							<?php if($errors->has('long')): ?>
							<span class="text-danger"><?php echo e($errors->first('long')); ?></span>
							<?php endif; ?>
						</div>
					</div>
					<div class="form-group row">
						<label for="input-12" class="col-sm-2 col-form-label">Zip Code<span class="text-danger">*</span></label>
						<div class="col-sm-4">
							<input type="text" name="pincode" class="form-control" value="<?php echo e(old('pincode',$vendor_store->pincode)); ?>">
							<?php if($errors->has('pincode')): ?>
							<span class="text-danger"><?php echo e($errors->first('pincode')); ?></span>
							<?php endif; ?>
						</div>
						<label for="input-12" class="col-sm-2 col-form-label">Website link</label>
						<div class="col-sm-4">
							<input type="text" name="website_link" class="form-control" value="<?php echo e(old('website_link',$vendor_store->website_link)); ?>">
						</div>
					</div>
					<div class="form-group row">
						<label for="input-13" class="col-sm-2 col-form-label">Status<span class="text-danger">*</span></label>
						<div class="col-sm-4">
							<select name="status" class="form-control">
								<option value="">Select Status</option>
								<?php $ac_enable = ''; $de_disable = '';
									if(old('status')){
										if(old('status')=='enable'){
											$ac_enable = 'selected="selected"';
										}elseif(old('status')=='disable'){
											$de_disable = 'selected="selected"';
										}
									}else{
										if($vendor_store->status == 'enable'){
											$ac_enable = 'selected="selected"';
										}elseif($vendor_store->status == 'disable'){
											$de_disable = 'selected="selected"';
										}
									}
								?>
								<option value="enable"<?php echo e($ac_enable); ?>>Enable</option>
								<option value="disable"<?php echo e($de_disable); ?>>Disable</option>
							</select>
							<?php if($errors->has('status')): ?>
								<span class="text-danger"><?php echo e($errors->first('status')); ?></span>
							<?php endif; ?>
						</div>
						<label for="input-12" class="col-sm-2 col-form-label">Current Status<span class="text-danger">*</span></label>
						<div class="col-sm-4">
							<select name="current_status" class="form-control">
								<option value="">Select Current Status</option>
								<?php $ac_open = ''; $de_close = '';
										if(old('current_status')){
											if(old('current_status')=='open'){
												$ac_open = 'selected="selected"';
											}elseif(old('current_status')=='close'){
												$de_close = 'selected="selected"';
											}
										}else{
											if($vendor_store->open_status == 'open'){
												$ac_open = 'selected="selected"';
											}elseif($vendor_store->open_status == 'close'){
												$de_close = 'selected="selected"';
											}
										}
								?>
								<option value="open"<?php echo e($ac_open); ?>>Open</option>
								<option value="close"<?php echo e($de_close); ?>>Close</option>
							</select>
							<?php if($errors->has('current_status')): ?>
							<span class="text-danger"><?php echo e($errors->first('current_status')); ?></span>
							<?php endif; ?>
						</div>
					</div>
					<div class="form-group row">
						<label for="input-13" class="col-sm-2 col-form-label">Return Policy<span class="text-danger">*</span></label>
						<div class="col-sm-4">
							<input type="number" name="return_policy" class="form-control" value="<?php echo e(old('return_policy',$vendor_store->return_policy)); ?>" placeholder="Enter Return Policy"><span>Note:6+ days</span><br>
							<?php if($errors->has('return_policy')): ?>
								<span class="text-danger"><?php echo e($errors->first('return_policy')); ?></span>
							<?php endif; ?>
						</div>
						<label for="input-13" class="col-sm-2 col-form-label">Image</label>
						<div class="col-sm-4">
							<input type="file" name="image" class="form-control" value="<?php echo e(old('image')); ?>">
							<?php if($errors->has('image')): ?>
							<span class="text-danger"><?php echo e($errors->first('image')); ?></span>
							<?php endif; ?>
							<?php if($vendor_store->image): ?>
							<br>
							<a href="<?php echo e(url('public/images/stores/'.$vendor_store->image)); ?>" rel="prettyPhoto">
								<img src="<?php echo e(url('public/images/stores/'.$vendor_store->image)); ?>" style="width: 200px; height: auto;">
							</a>
							<?php endif; ?>
						</div>
					</div>
					<div class="form-group row">
						<label for="input-13" class="col-sm-2 col-form-label">Pickup Time Limit<span class="text-danger">*</span></label>
						<div class="col-sm-4">
							<input type="text" name="pickup_time_limit" class="form-control" value="<?php echo e(old('pickup_time_limit',$vendor_store->pickup_time_limit)); ?>" placeholder="Enter Return Policy">Note: Time limit in minutes
							<?php if($errors->has('pickup_time_limit')): ?>
								<span class="text-danger"><?php echo e($errors->first('pickup_time_limit')); ?></span>
							<?php endif; ?>
						</div>
						<label for="input-13" class="col-sm-2 col-form-label">Setup fee required<span class="text-danger">*</span></label>
						<div class="col-sm-4">
							<select name="setup_fee_required" class="form-control">
								<?php $fee_yes = ''; $fee_no = '';
									if(old('setup_fee_required')){
										if(old('setup_fee_required') == 'yes'){
											$fee_yes = 'selected="selected"';
										}elseif(old('setup_fee_required') == 'no'){
											$fee_no = 'selected="selected"';
										}
									}else{
										if($vendor_store->setup_fee_required == 'yes'){
											$fee_yes = 'selected="selected"';
										}elseif($vendor_store->setup_fee_required == 'no'){
											$fee_no = 'selected="selected"';
										}
									}
								?>
								<option value="yes" <?php echo e($fee_yes); ?>>Yes</option>
								<option value="no" <?php echo e($fee_no); ?>>No</option>
							</select>
							<?php if($errors->has('setup_fee_required')): ?>
								<span class="text-danger"><?php echo e($errors->first('setup_fee_required')); ?></span>
							<?php endif; ?>
						</div>
					</div>
					<center>
						<div class="form-footer">
							<button type="submit" class="btn btn-success"><i class="fa fa-check-square-o"></i> SAVE</button>
							<a href="<?php echo e(url('admin/vendor_store')); ?>"><button type="button" class="btn btn-danger"><i class="fa fa-times"></i> CANCEL</button></a>
						</div>
					</center>
				</form>
                </div>
			</div>
		</div>
	</div>
</div>
<!--End Row--> 
<script>
$('#autoclose-datepicker').datepicker({
	autoclose: true,
	todayHighlight: true
});
var countryID = "<?php echo e(old('country', $vendor_store->country)); ?>";
var stateID = "<?php echo e(old('state', $vendor_store->state)); ?>";
var cityID = "<?php echo e(old('city', $vendor_store->city)); ?>";

$(function() {

	setTimeout(function(){ getState(); }, 500);
	setTimeout(function(){ getCity(); }, 500);

	$("#country").change(function() {
		countryID = $(this).val();
		getState();
	});

	$("#state").change(function() {
		stateID = $(this).val();
		getCity();
	});
});

function getState(){
	if(countryID != ''){
		$.ajax({
			data: {
			"_token": "<?php echo e(csrf_token()); ?>"
			},
			url: "<?php echo e(url('/get-state')); ?>/"+countryID,
			type: "GET",
			dataType: 'json',
			success: function (data) {
				$('#state').empty();
				$.each(data, function(i, val) {
					$("#state").append('<option value=' +val.id + '>' + val.name + '</option>');
				});
				if($("#state option[value='"+stateID+"']").length > 0){
                    $('#state').val(stateID);
                }
			},
			error: function (data) {
			}
		});
	}else{
		 $("#country").val('');
	}
}

function getCity(){
	if(stateID != ''){
		$.ajax({
			data: {
			"_token": "<?php echo e(csrf_token()); ?>"
			},
			url: "<?php echo e(url('/get-city')); ?>/"+stateID,
			type: "GET",
			dataType: 'json',
			success: function (data) {
				$('#city').empty();
				$.each(data, function(i, val) {
					$("#city").append('<option value=' +val.id + '>' + val.name + '</option>');
				});
				if($("#city option[value='"+cityID+"']").length > 0){
                    $('#city').val(cityID);
                }
			},
			error: function (data) {
			}
		});
	}else{
		$("#state").val('');

	}
}
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gtvmcmgwqds4/public_html/resources/views/admin/vendor_store/edit.blade.php ENDPATH**/ ?>