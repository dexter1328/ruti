<?php $__env->startSection('content'); ?>
<?php if(session()->get('success')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">×</button>
        <div class="alert-icon">
            <i class="fa fa-check"></i>
        </div>
        <div class="alert-message">
            <span><strong>Success!</strong> <?php echo e(session()->get('success')); ?></span>
        </div>
</div>
<?php endif; ?>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header"><div class="left"><span>Return Orders</span></div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table id="example" class="table table-bordered">
                    <thead>
                        <tr>
                            <th >SR No.</th>
                            <th >Order Id</th>
                            <th >Vendor</th>
                            <th >Store</th>
                            <th >Customer</th>
                           
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $return_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$return_order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td ><?php echo e($return_order->id); ?></td>
                                <td ><?php echo e($return_order->owner_name); ?></td>
                                <td ><?php echo e($return_order->store_name); ?></td>
                                <td ><?php echo e($return_order->first_name); ?></td>
                               
                                <td>
                                    <a href="<?php echo e(route('vendor.order_return.show', $return_order->id)); ?>" class="edit" data-toggle="tooltip" data-placement="bottom" title="View ReturnOrder">
                                        <i class="icon-eye icons"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th >SR No.</th>
                            <th >Order Id</th>
                            <th >Vendor</th>
                            <th >Store</th>
                            <th >Customer</th>
                           
                            <th>Action</th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    var table = $('#example').DataTable( {
        lengthChange: false,
            buttons: [
            {
                extend: 'copy',
                title: 'Return Order List',
                exportOptions: {
                columns: [ 0, 1,2,3,4]
                }
            },
            {
                extend: 'excelHtml5',
                title: 'Return Order List',
                exportOptions: {
                columns: [ 0, 1, 2,3,4]
                }
            },
            {
                extend: 'pdfHtml5',
                title: 'Return Order List',
                exportOptions: {
                columns: [ 0, 1, 2,3,4]
                }
            },
            {
                extend: 'print',
                title: 'Return Order List',
                autoPrint: true,
                exportOptions: {
                columns: [ 0, 1, 2,3,4]
                }
            },
            'colvis'
        ],
        columnDefs: [
            { "orderable": false, "targets": 5 }
        ]
    });
    table.buttons().container()
    .appendTo( '#example_wrapper .col-md-6:eq(0)' );
} );
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('vendor.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\work\ruti\resources\views/vendor/orders_returns/index.blade.php ENDPATH**/ ?>