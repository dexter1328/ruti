<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <div class="left"><span>Footerr</span></div>
            </div>
            <div class="card-body">
            	<div class="container-fluid">
                    <?php if(session()->get('success')): ?>
                        <div class="alert alert-success alert-dismissible" role="alert">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <div class="alert-icon">
                                <i class="fa fa-check"></i>
                            </div>
                            <div class="alert-message">
                                <span><strong>Success!</strong> <?php echo e(session()->get('success')); ?></span>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div id="ajaxMsg"></div>
                    <form id="addFrm" method="post" action="<?php echo e(route('pagemeta.footer')); ?>" enctype="multipart/form-data"> 
                        <?php echo csrf_field(); ?> 
                        <div class="form-group">
                            <label for="title">Title<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="title" value="<?php echo e(old('title', isset($footer['footer_title']) ? $footer['footer_title'] : '')); ?>"> 
                            <?php if($errors->has('title')): ?> 
                                <span class="text-danger"><?php echo e($errors->first('title')); ?></span> 
                            <?php endif; ?> 
                        </div>
                        <div class="form-group">
                            <label for="description">Description<span class="text-danger">*</span></label>
                            <textarea class="form-control" name="description" rows="5"><?php echo e(old('description', isset($footer['footer_description']) ? $footer['footer_description'] : '')); ?></textarea>
                            <?php if($errors->has('description')): ?> 
                                <span class="text-danger"><?php echo e($errors->first('description')); ?></span> 
                            <?php endif; ?> 
                        </div>
                        <div class="form-group">
                            <label for="facebook_link">Facebook Link<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="facebook_link" value="<?php echo e(old('facebook_link', isset($footer['footer_facebook_link']) ? $footer['footer_facebook_link'] : '')); ?>"> 
                            <?php if($errors->has('facebook_link')): ?> 
                                <span class="text-danger"><?php echo e($errors->first('facebook_link')); ?></span> 
                            <?php endif; ?> 
                        </div>
                        <div class="form-group">
                            <label for="twitter_link">Twitter Link<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="twitter_link" value="<?php echo e(old('twitter_link', isset($footer['footer_twitter_link']) ? $footer['footer_twitter_link'] : '')); ?>"> 
                            <?php if($errors->has('twitter_link')): ?> 
                                <span class="text-danger"><?php echo e($errors->first('twitter_link')); ?></span> 
                            <?php endif; ?> 
                        </div>
                        <div class="form-group">
                            <label for="linkedin_link">LinkedIn Link<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="linkedin_link" value="<?php echo e(old('linkedin_link', isset($footer['footer_linkedin_link']) ? $footer['footer_linkedin_link'] : '')); ?>"> 
                            <?php if($errors->has('linkedin_link')): ?> 
                                <span class="text-danger"><?php echo e($errors->first('linkedin_link')); ?></span> 
                            <?php endif; ?> 
                        </div>
                        <div class="form-group">
                            <label for="instagram_link">Instagram Link<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="instagram_link" value="<?php echo e(old('instagram_link', isset($footer['footer_instagram_link']) ? $footer['footer_instagram_link'] : '')); ?>"> 
                            <?php if($errors->has('instagram_link')): ?> 
                                <span class="text-danger"><?php echo e($errors->first('instagram_link')); ?></span> 
                            <?php endif; ?> 
                        </div>
                        <div class="form-group">
                            <label for="pinterest_link">Pinterest Link<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="pinterest_link" value="<?php echo e(old('pinterest_link', isset($footer['footer_pinterest_link']) ? $footer['footer_pinterest_link'] : '')); ?>"> 
                            <?php if($errors->has('pinterest_link')): ?> 
                                <span class="text-danger"><?php echo e($errors->first('pinterest_link')); ?></span> 
                            <?php endif; ?> 
                        </div>
                        <div class="form-group">
                            <label for="tiktok_link">TikTok Link<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="tiktok_link" value="<?php echo e(old('tiktok_link', isset($footer['footer_tiktok_link']) ? $footer['footer_tiktok_link'] : '')); ?>"> 
                            <?php if($errors->has('tiktok_link')): ?> 
                                <span class="text-danger"><?php echo e($errors->first('tiktok_link')); ?></span> 
                            <?php endif; ?> 
                        </div>
                        <center>
                            <button type="submit" id="submitBtn" class="btn btn-success"><i class="fa fa-check-square-o"></i> SAVE</button>
                        </center>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('employee.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gtvmcmgwqds4/public_html/resources/views/employee/footer.blade.php ENDPATH**/ ?>