<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-lg-12">
		<div class="card">
			<div class="card-header">
				<div class="left"><!-- <i class="fa fa-group"></i> --><span>Edit <?php echo e(ucfirst($membership->type)); ?> Memership</span>
				</div>
			</div>
			<div class="card-body">
            	<div class="container-fluid">
					<form id="signupForm" method="post" action="<?php echo e(route('membership.update',$membership->id)); ?>" enctype="multipart/form-data">
						<?php echo csrf_field(); ?>
						<?php echo method_field('PATCH'); ?>
						<input type="hidden" name="type" value="<?php echo e($membership->type); ?>">
						<div class="form-group row">
							<label for="input-11" class="col-sm-2 col-form-label">Name<span class="text-danger">*</span></label>
							<div class="col-sm-10">
								<input type="text" class="form-control" name="name" id="name" placeholder="Enter Name" value="<?php echo e(old('name', $membership->name)); ?>" readonly="readonly">
								<?php if($errors->has('name')): ?>name
									<span class="text-danger"><?php echo e($errors->first('name')); ?></span>
								<?php endif; ?>
							</div>
						</div>
						<?php if($membership->code != 'one_time_setup_fee'): ?>
							<?php echo $__env->make('admin.memberships.membership-feature', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						<?php endif; ?>
						<?php /* ?>
						<?php if($membership->type == 'vendor' && ($membership->code == 'sprout' || $membership->code == 'blossom')): ?>
							<?php echo $__env->make('admin.memberships.vendor-membership-feature', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						<?php elseif($membership->type == 'customer'): ?>
							<?php echo $__env->make('admin.memberships.customer-membership-feature', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						<?php endif; ?>
						<?php /* ?>
						<div class="form-group row">
							<label for="input-11" class="col-sm-2 col-form-label">Description</label>
							<div class="col-sm-10">
								<textarea class="form-control" name="description" placeholder="Enter Description"><?php echo e(old('description', $membership->description)); ?></textarea>
								<?php if($errors->has('description')): ?>
									<span class="text-danger"><?php echo e($errors->first('description')); ?></span>
								<?php endif; ?>
							</div>
						</div>
						<?php */ ?>
						<div class="form-group row">
							<label for="input-10" class="col-sm-2 col-form-label">Price<span class="text-danger">*</span></label>
							<div class="col-sm-10">
								<input type="text" class="form-control" placeholder="Enter Price" value="<?php echo e($membership->price?:0); ?>" readonly>
							</div>
						</div>
						<center>
							<div class="form-footer">
								<button type="submit" class="btn btn-success"><i class="fa fa-check-square-o"></i> SAVE</button>
								<a href="<?php echo e(url('admin/membership/list/'.$membership->type)); ?>"><button type="button" class="btn btn-danger"><i class="fa fa-times"></i> CANCEL</button></a>
							</div>
						</center>
					</form>
                </div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\work\ruti\resources\views//admin/memberships/edit.blade.php ENDPATH**/ ?>