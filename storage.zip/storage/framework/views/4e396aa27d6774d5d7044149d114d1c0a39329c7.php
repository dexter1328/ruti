<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-lg-12">
		<div class="card">
			<div class="card-header">
				<div class="left">
					<!-- <i class="fa fa-users"></i> --><span>Edit Customer</span>
				</div>
			</div>
			<div class="card-body">
            	<div class="container-fluid">
					<form id="signupForm" method="post" action="<?php echo e(route('customer.update',$customer->id)); ?>" enctype="multipart/form-data">
						<?php echo csrf_field(); ?>
						<?php echo method_field('PATCH'); ?>
						<div class="form-group row">
							<label for="input-11" class="col-sm-2 col-form-label">First Name<span class="text-danger">*</span></label>
							<div class="col-sm-4">
								<input type="text" class="form-control" id="input-10" name="first_name" placeholder="Enter First Name" value="<?php echo e(old('first_name',$customer->first_name)); ?>">
								<?php if($errors->has('first_name')): ?>
									<span class="text-danger"><?php echo e($errors->first('first_name')); ?></span>
								<?php endif; ?>
							</div>
							<label for="input-10" class="col-sm-2 col-form-label">Last Name<span class="text-danger">*</span></label>
							<div class="col-sm-4">
								<input type="text" class="form-control" id="input-10" name="last_name" placeholder="Enter Last Name" value="<?php echo e(old('first_name',$customer->last_name)); ?>">
								<?php if($errors->has('last_name')): ?>
									<span class="text-danger"><?php echo e($errors->first('last_name')); ?></span>
								<?php endif; ?>
							</div>
						</div>
						<div class="form-group row">
							<label for="input-11" class="col-sm-2 col-form-label">Email<span class="text-danger">*</span></label>
							<div class="col-sm-4">
								<input type="email" class="form-control" id="input-10" name="email" placeholder="Enter E-mail" value="<?php echo e(old('email',$customer->email)); ?>">
								<?php if($errors->has('email')): ?>
									<span class="text-danger"><?php echo e($errors->first('email')); ?></span>
								<?php endif; ?>
							</div>
							<label for="input-10" class="col-sm-2 col-form-label">DOB<span class="text-danger">*</span></label>
							<div class="col-sm-4">
								<input type="text" class="form-control" id="autoclose-datepicker" name="dob" placeholder="Enter DOB" value="<?php echo e(old('dob',date('m/d/Y', strtotime($customer->dob)))); ?>">
								<?php if($errors->has('dob')): ?>
									<span class="text-danger"><?php echo e($errors->first('dob')); ?></span>
								<?php endif; ?>
							</div>
						</div>
						<div class="form-group row">
							<label for="input-11" class="col-sm-2 col-form-label">Anniversary Date</label>
							<div class="col-sm-4">
								<input type="text" class="form-control" id="autoclose-datepicker1" name="anniversary_date" placeholder="Enter Anniversary Date" value="<?php if($customer->anniversary_date): ?><?php echo e(old('anniversary_date',date('m/d/Y', strtotime($customer->anniversary_date)))); ?><?php endif; ?>">
								<?php if($errors->has('anniversary_date')): ?>
									<span class="text-danger"><?php echo e($errors->first('anniversary_date')); ?></span>
								<?php endif; ?>
							</div>
							<label for="input-10" class="col-sm-2 col-form-label">Mobile<span class="text-danger">*</span></label>
							<div class="col-sm-4">
								<input type="text" class="form-control" id="input-10" name="mobile" placeholder="Enter Mobile Number" value="<?php echo e(old('mobile',$customer->mobile)); ?>">
								<?php if($errors->has('mobile')): ?>
									<span class="text-danger"><?php echo e($errors->first('mobile')); ?></span>
								<?php endif; ?>
							</div>
						</div>
						<div class="form-group row">
							<label for="input-10" class="col-sm-2 col-form-label">Address<span class="text-danger">*</span></label>
							<div class="col-sm-4">
								<textarea class="form-control" id="input-10" name="address" placeholder="Enter Address"><?php echo e(old('address',$customer->address)); ?></textarea>
								<?php if($errors->has('address')): ?>
									<span class="text-danger"><?php echo e($errors->first('address')); ?></span>
								<?php endif; ?>
							</div>
							<label for="input-11" class="col-sm-2 col-form-label">Country<span class="text-danger">*</span></label>
							<div class="col-sm-4">
								<select class="form-control" name="country" id="country">
									<option value="">Select Country</option>
									<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($country->id); ?>"<?php echo e((old("country", $customer->country) == $country->id ? "selected":"")); ?>><?php echo e($country->name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
								<?php if($errors->has('country')): ?>
									<span class="text-danger"><?php echo e($errors->first('country')); ?></span>
								<?php endif; ?>
							</div>
						</div>
						<div class="form-group row">
							<label for="input-10" class="col-sm-2 col-form-label">State<span class="text-danger">*</span></label>
							<div class="col-sm-4">
								<select class="form-control" id="state" name="state" value="<?php echo e(old('state')); ?>">
									<option value="">Select State</option>
								</select>
								<?php if($errors->has('state')): ?>
									<span class="text-danger"><?php echo e($errors->first('state')); ?></span>
								<?php endif; ?>
							</div>
							<label for="input-11" class="col-sm-2 col-form-label">City<span class="text-danger">*</span></label>
							<div class="col-sm-4">
								<select class="form-control" id="city" name="city" value="<?php echo e(old('city')); ?>">
									<option value="">Select State</option>
								</select>
								<?php if($errors->has('city')): ?>
									<span class="text-danger"><?php echo e($errors->first('city')); ?></span>
								<?php endif; ?>
							</div>
						</div>
						<div class="form-group row">
							<label for="input-10" class="col-sm-2 col-form-label">Latitude</label>
							<div class="col-sm-4">
								<input type="text" class="form-control" id="input-10" name="lat" placeholder="Enter Latitude" value="<?php echo e(old('lat',$customer->lat)); ?>">
								<?php if($errors->has('lat')): ?>
									<span class="text-danger"><?php echo e($errors->first('lat')); ?></span>
								<?php endif; ?>
							</div>
							<label for="input-11" class="col-sm-2 col-form-label">Longitude</label>
							<div class="col-sm-4">
								<input type="text" class="form-control" id="input-10" name="long" placeholder="Enter Longitude" value="<?php echo e(old('long',$customer->long)); ?>">
								<?php if($errors->has('long')): ?>
									<span class="text-danger"><?php echo e($errors->first('long')); ?></span>
								<?php endif; ?>
							</div>
						</div>
						<div class="form-group row">
							<label for="input-10" class="col-sm-2 col-form-label">Zip Code<span class="text-danger">*</span></label>
							<div class="col-sm-4">
								<input type="text" class="form-control" id="input-10" name="pincode" placeholder="Enter Zip Code" value="<?php echo e(old('pincode',$customer->pincode)); ?>">
								<?php if($errors->has('pincode')): ?>
									<span class="text-danger"><?php echo e($errors->first('pincode')); ?></span>
								<?php endif; ?>
							</div>
							<label for="input-11" class="col-sm-2 col-form-label">Receive Newsletter<span class="text-danger">*</span></label>
							<div class="col-sm-4">
								<input type="text" class="form-control" id="input-10" name="receive_newsletter" placeholder="Enter Newsletter" value="<?php echo e(old('receive_newsletter',$customer->receive_newsletter)); ?>">
								<?php if($errors->has('receive_newsletter')): ?>
									<span class="text-danger"><?php echo e($errors->first('receive_newsletter')); ?></span>
								<?php endif; ?>
							</div>
						</div>
						<div class="form-group row">
							<label for="input-10" class="col-sm-2 col-form-label">Terms & Condition<span class="text-danger">*</span></label>
							<div class="col-sm-4">
								<input type="text" class="form-control" id="input-10" name="terms_conditions" placeholder="Enter Terms & Condition" value="<?php echo e(old('terms_conditions',$customer->terms_conditions)); ?>">
								<?php if($errors->has('terms_conditions')): ?>
									<span class="text-danger"><?php echo e($errors->first('terms_conditions')); ?></span>
								<?php endif; ?>
							</div>
							<label for="input-13" class="col-sm-2 col-form-label">Status<span class="text-danger">*</span></label>
							<div class="col-sm-4">
								<select name="status" class="form-control">
									<option value="">Select Status</option>
										<?php $ac_status = ''; $de_status = '';
											if(old('status')){
												if(old('status')=='active'){
													$ac_status = 'selected="selected"';
												}elseif(old('status')=='deactive'){
													$de_status = 'selected="selected"';
												}
											}
											else{
												if($customer->status == 'active'){
													$ac_status = 'selected="selected"';
												}elseif($customer->status == 'deactive'){
													$de_status = 'selected="selected"';
												}
											}
										?>
									<option value="active"<?php echo e($ac_status); ?>>Active</option>
									<option value="deactive"<?php echo e($de_status); ?>>Deactive</option>
								</select>
								<?php if($errors->has('status')): ?>
									<span class="text-danger"><?php echo e($errors->first('status')); ?></span>
								<?php endif; ?>
							</div>
						</div>
						<center>
							<div class="form-footer">
								<button type="submit" class="btn btn-success"><i class="fa fa-check-square-o"></i> SAVE</button>
								<a href="<?php echo e(url('admin/customer')); ?>"><button type="button" class="btn btn-danger"><i class="fa fa-times"></i> CANCEL</button></a>
							</div>
						</center>
					</form>
                </div>
			</div>
		</div>
	</div>
</div>
<!--End Row--> 
<script type="text/javascript">

var countryID = "<?php echo e(old('country' , $customer->country)); ?>";
var stateID = "<?php echo e(old('state' , $customer->state)); ?>";
var cityID = "<?php echo e(old('city' , $customer->city)); ?>";

$(function() {
	setTimeout(function(){ getState(); }, 500);
	setTimeout(function(){ getCity(); }, 500);

	$("#country").change(function() {
		countryID = $(this).val();
		getState();
	});

	$("#state").change(function() {
		stateID = $(this).val();
		getCity();
	});
});

function getState(){
	if(countryID != ''){
		$.ajax({
			data: {
			"_token": "<?php echo e(csrf_token()); ?>"
			},
			url: "<?php echo e(url('/get-state')); ?>/"+countryID,
			type: "GET",
			dataType: 'json',
			success: function (data) {
				$('#state').empty();
				$.each(data, function(i, val) {
					$("#state").append('<option value=' +val.id + '>' + val.name + '</option>');
				});
				if($("#state option[value='"+stateID+"']").length > 0){
                    $('#state').val(stateID);
                }
			},
			error: function (data) {
			}
		});
	}else{
		$("#country").val('');
	}
}

function getCity(){
	if(stateID != ''){
		$.ajax({
			data: {
			"_token": "<?php echo e(csrf_token()); ?>"
			},
			url: "<?php echo e(url('/get-city')); ?>/"+stateID,
			type: "GET",
			dataType: 'json',
			success: function (data) {
				$('#city').empty();
				$.each(data, function(i, val) {
					$("#city").append('<option value=' +val.id + '>' + val.name + '</option>');
				});
				if($("#city option[value='"+cityID+"']").length > 0){
                    $('#city').val(cityID);
                }
			},
			error: function (data) {
			}
		});
	}else{
		$("#state").val('');
	}
}
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gtvmcmgwqds4/public_html/resources/views/admin/customers/edit.blade.php ENDPATH**/ ?>