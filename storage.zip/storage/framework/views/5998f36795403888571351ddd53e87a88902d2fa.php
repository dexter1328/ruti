<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-lg-12">
		<div class="card">
			<div class="card-header">
				<div class="left"><!-- <i class="fa fa-address-book-o"></i> --><span>Edit Admin</span></div>
			</div>
			<div class="card-body">
            	<div class="container-fluid">
					<form id="signupForm" method="post" action="<?php echo e(route('admins.update',$admin->id)); ?>" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
					<?php echo method_field('PATCH'); ?>
					<div class="form-group row">
						<label for="input-10" class="col-sm-2 col-form-label">Name<span class="text-danger">*</span></label>
						<div class="col-sm-4">
							<input type="text" class="form-control" id="input-10" name="name" placeholder="Enter Name" 
							value="<?php echo e(old('name',$admin->name)); ?>">
							<?php if($errors->has('name')): ?>
								<span class="text-danger"><?php echo e($errors->first('name')); ?></span>
							<?php endif; ?>
						</div>
						<label for="input-11" class="col-sm-2 col-form-label">Email<span class="text-danger">*</span></label>
						<div class="col-sm-4">
							<input type="email" class="form-control" id="input-11" name="email" placeholder="Enter Email" value="<?php echo e(old('email',$admin->email)); ?>">
							<?php if($errors->has('email')): ?>
								<span class="text-danger"><?php echo e($errors->first('email')); ?></span>
							<?php endif; ?>
						</div>
					</div>
					<div class="form-group row">
						<label for="input-8" class="col-sm-2 col-form-label">Image</label>
						<div class="col-sm-4">
							<input type="file" class="form-control" id="input-8" name="image" value="">
							<?php if($admin->image): ?>
								<?php $image = asset('public/images/'.$admin->image); ?>
								<br>
								<img class="img-responsive" id="imagePreview" src="<?php echo e($image); ?>" height="100" width="100">
							<?php endif; ?>
						</div>
						<label for="role_id" class="col-sm-2 col-form-label">Role<span class="text-danger">*</span></label>
                        <div class="col-sm-4">
                            <?php $roles = DB::table('admin_roles')->get(); ?>
                            <select class="form-control" id="role_id" name="role_id">
                                <option value="">Select Role</option>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                	<?php if(old('role_id')){
                                		$selected = ($role->id == old('role_id') ? 'selected="selected"' : ''); 
                                	}else{
                                		$selected = ($role->id == $admin->role_id ? 'selected="selected"' : '');
                                	} ?>
                                	<option value="<?php echo e($role->id); ?>" <?php echo e($selected); ?>><?php echo e($role->role_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('role_id')): ?>
								<span class="text-danger"><?php echo e($errors->first('role_id')); ?></span>
							<?php endif; ?>
                        </div>
					</div>
					<div class="form-group row">
						<label for="input-13" class="col-sm-2 col-form-label">Status<span class="text-danger">*</span></label>
						<div class="col-sm-10">
							<select name="status" class="form-control">
								<option value="">Select Status</option>
									<?php $ac_status = ''; $de_status = '';
										if(old('status')){
											if(old('status')=='active'){
												$ac_status = 'selected="selected"';
											}elseif(old('status')=='deactive'){
												$de_status = 'selected="selected"';
											}
										}else{
											if($admin->status == 'active'){
												$ac_status = 'selected="selected"';
											}elseif($admin->status == 'deactive'){
												$de_status = 'selected="selected"';
											}
										}
									?>
								<option value="active"<?php echo e($ac_status); ?>>Active</option>
								<option value="deactive"<?php echo e($de_status); ?>>Deactive</option>
							</select>
							<?php if($errors->has('status')): ?>
								<span class="text-danger"><?php echo e($errors->first('status')); ?></span>
							<?php endif; ?>
						</div>
					</div>
					<center>
						<div class="form-footer">
							<button type="submit" class="btn btn-success"><i class="fa fa-check-square-o"></i> SAVE</button>
							<a href="<?php echo e(url('admin/admins')); ?>"><button type="button" class="btn btn-danger"><i class="fa fa-times"></i> CANCEL</button></a>
						</div>
					</center>
				</form>
                </div>
			</div>
		</div>
	</div>
</div>
<!--End Row--> 
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gtvmcmgwqds4/public_html/resources/views/admin/admin/edit.blade.php ENDPATH**/ ?>