<!DOCTYPE html>
<html>
<head>
    <title>Ruti Self Checkout</title>
</head>
<body>
    <h1><?php echo e($details['title']); ?></h1><br>
    


<p>Hey there, we noticed you haven't made any progress on your application in last few days,
     Let us know if you have any questions or issues!</p> <br>

<p>If not, complete or respond to the next items.</p> <br>
<a href="rutiselfcheckout.com">View</a><br>
<p>Best Regards!</p> <br>
<p>Ruti Self Checkout</p>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\work\ruti\resources\views/email/wb_order/cart_order.blade.php ENDPATH**/ ?>