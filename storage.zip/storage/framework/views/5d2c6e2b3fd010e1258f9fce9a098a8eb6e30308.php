<?php $__env->startSection('content'); ?>
<?php if(session()->get('success')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
	<button type="button" class="close" data-dismiss="alert">×</button>
	<div class="alert-icon">
		<i class="fa fa-check"></i>
	</div>
	<div class="alert-message">
		<span><strong>Success!</strong> <?php echo e(session()->get('success')); ?></span>
	</div>
</div>
<?php endif; ?>
<div class="row">
	<div class="col-lg-12">
		<div class="card">
			<div class="card-header">
				<div class="left"><!-- <i class="fa fa-cog"></i> --><span>Settings</span></div>
			</div>
			<div class="card-body">
            	<div class="container-fluid">
					<form id="signupForm" method="post" action="<?php echo e(route('supplier.settings.store')); ?>" enctype="multipart/form-data"> 
						<?php echo csrf_field(); ?>
						<!-- <div class="form-group row">
							<label class="col-sm-12 col-form-label">Suspend Customer Account</label>
						</div> -->
						<div class="form-group row">
							<label for="input-13" class="col-sm-3 col-form-label">Inventory Update Reminder<span class="text-danger">*</span></label>
							<div class="col-sm-6">
								<div class="input-group mb-3">
									<select class="form-control" name="setting[inventory_update_reminder_day]">
										<option value="">Select Day</option>
										<?php $__currentLoopData = weekdays(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									 		<?php $selected = '';
											if(isset($setting['inventory_update_reminder_day']) && $value == $setting['inventory_update_reminder_day']) {
												$selected = 'selected="selected"';
											} ?>
											<option value="<?php echo e($value); ?>" <?php echo e($selected); ?>><?php echo e($value); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
									<select class="form-control" name="setting[inventory_update_reminder_time]">
										<option value="">Select Time</option>
										<?php $__currentLoopData = vendor_store_hours(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php $selected = '';
											if(isset($setting['inventory_update_reminder_time']) && $time->format('H:i') == $setting['inventory_update_reminder_time']) {
												echo $selected = 'selected="selected"';
											} ?>
											<option value="<?php echo e($time->format('H:i')); ?>" <?php echo e($selected); ?>><?php echo e($time->format('H:i')); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
								<?php if($errors->has('setting.inventory_update_reminder_day') || $errors->has('setting.inventory_update_reminder_time')): ?>
									<span class="text-danger">Inventory update reminder day and time fields are required.</span>
								<?php endif; ?>
							</div>
							<div class="col-sm-3 text-center">
								<?php if(vendor_has_permission(Auth::user()->role_id,'setting','write') ): ?>
							
										<button type="submit" class="btn btn-success"><i class="fa fa-check-square-o"></i> SAVE</button>
							
								<?php endif; ?>
							</div>
						</div>
					</form>
                </div>

				
	
				<table class="table table-bordered">
					<thead>
					  <tr>
						<th colspan="3" >Current Fullfill type: <span style="font-weight: bold; color:darkgoldenrod; font-size:15px;"> <?php echo e(Auth::user()->fullfill_type); ?></span></th>
					  </tr>
					</thead>
					<form action="<?php echo e(route('fullfill_type_change',$fullfill_type->id)); ?>" enctype="multipart/form-data" method="post">
						<?php echo csrf_field(); ?>
					<tbody>
					  <tr>
						<td style="width: 25%" ><input type="radio" id="full-fill" name="fullfill_type" value="seller_fullfill" <?php echo e($fullfill_type->fullfill_type == 'seller_fullfill' ? "checked" : ""); ?> required> Seller Fullfill</td>
						<td>Seller fulfill means wholesalers product will be shipped to Seller designated location.</td>
						<td rowspan="2" class="text-center"><button type="submit" class="btn btn-success"><i class="fa fa-check-square-o"></i> Change Type</button></td>
					  </tr>
					  <tr>
						<td style="width: 25%" ><input type="radio" id="full-fill" name="fullfill_type" value="ruti_fullfill" <?php echo e($fullfill_type->fullfill_type == 'ruti_fullfill' ? "checked" : ""); ?> required> Ruti Fullfill</td>
						<td>Ruti fulfill comes with a cost at $39 per month. And wholesalers will ship to Ruti warehouse. Ruti will distribute seller products to customer/buyer when they buy</td>
					  </tr>
					</tbody>
					</form>
				  </table>
				
				<div class="mt-5">
					<form id="signupForm" method="post" action="<?php echo e(route('setReminderToBuyer')); ?>" enctype="multipart/form-data"> 
						<?php echo csrf_field(); ?>
						<div class="form-group row">
							<label for="input-13" class="col-sm-3 col-form-label">Buyer purchasing Reminder<span class="text-danger">*</span></label>
							<div class="col-sm-6">
								<div class="input-group mb-3">
									<select class="form-control" name="dayValue" required>
										<option value="">Select Day</option>
										<?php $__currentLoopData = weekdays(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
									<input type="time" class="form-control" name="timeValue" required>
								</div>
							</div>
							<div class="col-sm-3 text-center">
								<?php if(vendor_has_permission(Auth::user()->role_id,'setting','write') ): ?>
								<button type="submit" class="btn btn-success"><i class="fa fa-check-square-o"></i> SAVE</button>
								<?php endif; ?>
							</div>
						</div>
					</form>
                </div>

			</div>
		</div>
	</div>
</div>
<!--End Row-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('supplier.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\work\ruti\resources\views/supplier/settings/index.blade.php ENDPATH**/ ?>