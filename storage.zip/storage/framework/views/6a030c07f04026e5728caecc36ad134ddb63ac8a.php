<?php $__env->startSection('content'); ?>
<style type="text/css">
    .field-icon {
        float: right;
        margin-right: 20px;
        margin-top: -26px;
        z-index: 2;
    }
</style>
<div class="card-body">
    <div class="card-content p-2">
        <div class="text-center">
            <img src="<?php echo e(asset('public/images/logo-icon-xx.png')); ?>" alt="logo icon">
        </div>
        <div class="card-title text-uppercase text-center py-3">Supplier Sign In</div>

        <form class="form-horizontal" method="POST" action="<?php echo e(url('/supplier/login')); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="email" class="sr-only">E-Mail Address</label>
                <div class="position-relative has-icon-right">
                    <input type="email" id="email" class="form-control input-shadow <?php echo e($errors->has('email') ? 'error' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="E-Mail Address" autofocus>
                    <div class="form-control-position">
                        <i class="icon-user"></i>
                    </div>
                    <?php if($errors->has('email')): ?>
                        <label class="error"><?php echo e($errors->first('email')); ?></label>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group">
                <label for="password" class="sr-only">Password</label>
                <div class="position-relative has-icon-right">
                    <input type="password" id="password" class="form-control input-shadow <?php echo e($errors->has('password') ? 'error' : ''); ?>" name="password" placeholder="Password">
                    <span toggle="#password" class="fa fa-eye field-icon toggle-password"></span>
                    <!-- <div class="form-control-position">
                        <i class="icon-lock"></i>
                    </div> -->
                    <?php if($errors->has('password')): ?>
                        <label class="error"><?php echo e($errors->first('password')); ?></label>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-6">
                    <div class="icheck-material-primary">
                        <input type="checkbox" id="user-checkbox" name="remember" checked="" />
                        <label for="user-checkbox">Remember me</label>
                    </div>
                </div>
                <div class="form-group col-6 text-right">
                    <a href="<?php echo e(url('/supplier/password/reset')); ?>">Reset Password</a>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-12" style="text-align: center;">
                    
                    New to Nature Checkout? <a href="<?php echo e(url('/supplier/signup')); ?>">Create an Account</a>
                </div>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Sign In</button>
            <a href="<?php echo e(url('/')); ?>" style="background-color:#ee7322;color:#fff !important;" class="btn btn-block">Home</a>
        </form>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function(){
        $(".toggle-password").click(function() {

            $(this).toggleClass("fa-eye fa-eye-slash");
            var input = $($(this).attr("toggle"));
            if (input.attr("type") == "password") {
                input.attr("type", "text");
            } else {
                input.attr("type", "password");
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('supplier.layout.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\work\ruti\resources\views/supplier/auth/login.blade.php ENDPATH**/ ?>