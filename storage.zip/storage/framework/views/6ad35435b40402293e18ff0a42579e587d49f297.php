<?php
	if(old('description')){
		$description = (object)old('description');
	}else if($membership->description!=''){
		$description = $membership->description;
	}
?>
<?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php if($feature['type'] == 'array'): ?>
		<div class="form-group row">
			<label for="input-11" class="col-sm-12 col-form-label"><?php echo e($feature['label']); ?></label>
		</div>
		<?php $__currentLoopData = $feature['values']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $license): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="form-group row">
				<label for="input-11" class="col-sm-2 col-form-label"><?php echo e($license['label']); ?></label>
				<div class="col-sm-10">
					<?php if($license['type'] == 'select'): ?>
						<select class="form-control" name="features[<?php echo e($key); ?>][<?php echo e($key2); ?>]">
							<option value="">-- Select --</option>
							<?php $__currentLoopData = $license['values']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php $slctd = (array_key_exists($key2,(array)$description->$key) && $description->$key->$key2 == $value ? 'selected="selected"' : ''); ?>
								<option value="<?php echo e($value); ?>" <?php echo e($slctd); ?>><?php echo e($value); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					<?php elseif($license['type'] == 'checkbox'): ?>
						<?php $__currentLoopData = $license['values']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php $chkd = (array_key_exists($key2,(array)$description->$key) && $description->$key->$key2 == $value ? 'checked="checked"' : ''); ?>
							<input type="checkbox" name="features[<?php echo e($key); ?>][<?php echo e($key2); ?>]" value="<?php echo e($value); ?>" <?php echo e($chkd); ?>> <?php echo e($value); ?>

						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				</div>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php else: ?>
		<div class="form-group row">
			<label for="input-11" class="col-sm-2 col-form-label"><?php echo e($feature['label']); ?></label>
			<div class="col-sm-10">
				<?php if($feature['type'] == 'select'): ?>
					<select class="form-control" name="features[<?php echo e($key); ?>]">
						<option value="">-- Select --</option>
						<?php $__currentLoopData = $feature['values']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php $slctd = (array_key_exists($key,(array)$description) && $description->$key == $value ? 'selected="selected"' : ''); ?>
							<option value="<?php echo e($value); ?>" <?php echo e($slctd); ?>><?php echo e($value); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				<?php elseif($feature['type'] == 'checkbox'): ?>
					<?php $__currentLoopData = $feature['values']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php $chkd = (array_key_exists($key,(array)$description) && $description->$key == $value ? 'checked="checked"' : ''); ?>
						<input type="checkbox" name="features[<?php echo e($key); ?>]" value="<?php echo e($value); ?>" <?php echo e($chkd); ?>> <?php echo e($value); ?>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
			</div>
		</div>	
	<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\work\ruti\resources\views/admin/memberships/membership-feature.blade.php ENDPATH**/ ?>