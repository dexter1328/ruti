<?php $__env->startSection('content'); ?>

<div class="container">

    <form class="form-horizontal" method="POST" action="<?php echo e(route('import_process')); ?>">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="csv_data_file_id" value="<?php echo e($csv_data_file->id); ?>" />

        <table class="table">
            <?php $__currentLoopData = $csv_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($value); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <?php $__currentLoopData = $csv_data[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td>
                        <select name="fields[<?php echo e($key); ?>]">
                            <?php $__currentLoopData = config('app.db_fields'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $db_field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($loop->index); ?>"><?php echo e($db_field); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </table>

        <button type="submit" class="btn btn-primary">
            Import Data
        </button>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('supplier.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\work\ruti\resources\views/supplier/products/upload_fields.blade.php ENDPATH**/ ?>