<!DOCTYPE html>
<html>
<head>
    <title>Ruti Self Checkout</title>
</head>
<body>
    <h1><?php echo e($details['title']); ?></h1><br>
    <p><?php echo e($details['body']); ?></p><br>
<h3><a href="http://www.rutiselfcheckout.com/admin/w2b_products/orders">Please Go to Admin Panel to take actions.</a></h3> <br>



<p>Best Regards!</p> <br>
<p>Ruti Self Checkout</p>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\work\ruti\resources\views/email/wb_order/ruti_order.blade.php ENDPATH**/ ?>