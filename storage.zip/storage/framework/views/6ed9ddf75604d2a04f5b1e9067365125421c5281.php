<input type="hidden" id="card_count" name="card_count" value="<?php echo e(count($cards)); ?>">
<ul class="list-group" id="cardListContent">
	<?php if(!empty($cards)): ?>
		<?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php 
			$card_id = $card['id'];
			$exp_month = sprintf('%02d', $card['exp_month']);
			$exp_year = substr($card['exp_year'], 2);
			?>
			<li class="list-group-item d-flex justify-content-between align-items-center">
				<div>
					<div class="mb-2">
						<span class="font-weight-bold"><?php echo e($card['brand']); ?> &#8226;&#8226;&#8226;&#8226; <?php echo e($card['last4']); ?></span>
						<?php if($card['default'] == 1): ?>
							<span class="card-badge-default">Default</span>
						<?php elseif($card['exp_month'] < date('m') && $card['exp_year'] < date('Y')): ?>
							<span class="card-badge-expired">Expired</span>
						<?php endif; ?>
					</div>
					<small>
						<?php if($card['exp_month'] < date('m') && $card['exp_year'] < date('Y')): ?>
							Expired
						<?php else: ?>
							Expires
						<?php endif; ?>
						<?php echo e(date("M", mktime(0, 0, 0, $card['exp_month'], 10))); ?> <?php echo e($card['exp_year']); ?>

					</small>
					<div class="card-action">
						<ul class="action-list">
							<li class="action-item">
								<a href="javascript:void(0);" onclick="editCard('<?php echo e($card_id); ?>','<?php echo e($exp_month); ?>','<?php echo e($exp_year); ?>');"><i class="icon-note icons"></i></a>
							</li>
							<li class="action-item">
								<a href="javascript:void(0);" onclick="deleteCard('<?php echo e($card_id); ?>');"><i class="icon-trash icons"></i></a>
							</li>
							<li class="action-item-last">
								<div class="dropdown show" >
									<a class="dropdown-toggle more-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="icon-options icons"></i></a>

									<div class="dropdown-menu more-menu" aria-labelledby="dropdownMenuLink">
										<a class="dropdown-item text-muted">Action</a>
										<a class="dropdown-item text-primary" href="javascript:void(0);" onclick="setDefaultCard('<?php echo e($card_id); ?>');">Set as Default</a>
										<a class="dropdown-item text-success" href="javascript:void(0);" onclick="editCard('<?php echo e($card_id); ?>','<?php echo e($exp_month); ?>','<?php echo e($exp_year); ?>');">Edit</a>
										<a class="dropdown-item text-danger" href="javascript:void(0);" onclick="deleteCard('<?php echo e($card_id); ?>');">Delete</a>
									</div>
								</div>
							</li>
						</ul>
					</div>
				</div>
			</li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php else: ?>
		<li class="list-group-item">No Cards Found.</li>
	<?php endif; ?>
</ul><?php /**PATH C:\xampp\htdocs\work\ruti\resources\views/supplier/suppliers/card-list.blade.php ENDPATH**/ ?>