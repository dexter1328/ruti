 <center>
      <img src="<?php echo e(asset('public/images/logo-icon-xx.png')); ?>" style="width:250px; height: auto;border: none; display: block; -ms-interpolation-mode: bicubic;">
</center>
<h2>Thank you for registering</h2>
<p>Hi <?php echo e($name); ?>,</p>
<p>Thank you for creating an account in RUTI Self Checkout. Below is your login credential:</p>
<b>Email Address: </b><?php echo e($email); ?><br>
<b>Password: </b>Your chosen password
<br>

<p>Here is a systematic guide to navigating RUTI Self Checkout:</p>
<br>
<b>1. Signup & Photo mandatory</b><br>
<b>2. Refer 20 friends minimum</b><br>
<b>3. Maintain $25 minimum in Wallet</b><br>
<b>4. Make a Store purchase</b><br>
<b>5. Refer a Vendor</b><br>
<b>6. Review and Go</b><br>
<p>If you have any questions regarding your account, click 'Reply' in your email client and we will be happy to assist.</p>
<p>
Thanks!<br>
RUTI Self Checkout Team
</p>
<?php /**PATH /home/gtvmcmgwqds4/public_html/resources/views//admin/customers/customer_signup.blade.php ENDPATH**/ ?>