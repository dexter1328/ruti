<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-lg-12">
		<div class="card">
			<div class="card-header">
				<div class="left"><!-- <i class="fa fa-users"></i> --><span>Add Vendor</span></div>
			</div>
			<div class="card-body">
            	<div class="container-fluid">
					<form id="signupForm" method="post" action="<?php echo e(route('vendor.store')); ?>" enctype="multipart/form-data">
						<?php echo csrf_field(); ?>
						<div class="form-group row">
							<label for="input-12" class="col-sm-2 col-form-label">Sales Person Name<span class="text-danger">*</span></label>
							<div class="col-sm-4">
								<input type="text" name="sales_person_name" class="form-control" value="<?php echo e(old('sales_person_name')); ?>">
								<?php if($errors->has('sales_person_name')): ?>
								<span class="text-danger"><?php echo e($errors->first('sales_person_name')); ?></span>
								<?php endif; ?>
							</div>
							<label for="input-12" class="col-sm-2 col-form-label">Sales Person Mobile Number<span class="text-danger">*</span></label>
							<div class="col-sm-4">
								<input type="text" name="sales_person_mobile_number" class="form-control" value="<?php echo e(old('sales_person_mobile_number')); ?>">
								<?php if($errors->has('sales_person_mobile_number')): ?>
									<span class="text-danger"><?php echo e($errors->first('sales_person_mobile_number')); ?></span>
								<?php endif; ?>
							</div>
						</div>
						<div class="form-group row">
							<label for="input-12" class="col-sm-2 col-form-label">Name<span class="text-danger">*</span></label>
							<div class="col-sm-4">
								<input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" placeholder="Enter Name">
								<?php if($errors->has('name')): ?>
								<span class="text-danger"><?php echo e($errors->first('name')); ?></span>
								<?php endif; ?>
							</div>
							<label for="input-12" class="col-sm-2 col-form-label">Email<span class="text-danger">*</span></label>
							<div class="col-sm-4">
								<input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>" placeholder="Enter E-mail">
								<?php if($errors->has('email')): ?>
									<span class="text-danger"><?php echo e($errors->first('email')); ?></span>
								<?php endif; ?>
							</div>
						</div>
						<div class="form-group row">
							<label for="input-13" class="col-sm-2 col-form-label">Password<span class="text-danger">*</span></label>
							<div class="col-sm-4">
								<input type="password" name="password" class="form-control" value="<?php echo e(old('password')); ?>" placeholder="Enter Password">
								<?php if($errors->has('password')): ?>
									<span class="text-danger"><?php echo e($errors->first('password')); ?></span>
								<?php endif; ?>
							</div>
							<label for="input-13" class="col-sm-2 col-form-label">Confirm Password<span class="text-danger">*</span></label>
	                        <div class="col-sm-4">
	                            <input type="password" name="confirm_password" class="form-control" value="<?php echo e(old('confirm_password')); ?>" placeholder="Enter Confirm Password">
	                            <?php if($errors->has('confirm_password')): ?>
	                                <span class="text-danger"><?php echo e($errors->first('confirm_password')); ?></span>
	                            <?php endif; ?>
	                        </div>
						</div>
						<div class="form-group row">
							<label for="input-12" class="col-sm-2 col-form-label">Business Name<span class="text-danger">*</span></label>
	                        <div class="col-sm-4">
	                            <input type="text" name="business_name" class="form-control" value="<?php echo e(old('business_name')); ?>" placeholder="Enter Business Name">
	                            <?php if($errors->has('business_name')): ?>
	                            <span class="text-danger"><?php echo e($errors->first('business_name')); ?></span>
	                            <?php endif; ?>
	                        </div>
							<label for="input-12" class="col-sm-2 col-form-label">Tax ID<span class="text-danger">*</span></label>
	                        <div class="col-sm-4">
	                            <input type="text" name="tax_id" class="form-control" value="<?php echo e(old('tax_id')); ?>" placeholder="Enter Tax ID">
	                            <?php if($errors->has('tax_id')): ?>
	                                <span class="text-danger"><?php echo e($errors->first('tax_id')); ?></span>
	                            <?php endif; ?>
	                        </div>
						</div>
						<div class="form-group row">
	                        <label for="input-12" class="col-sm-2 col-form-label">Phone Number</label>
							<div class="col-sm-4">
								<input type="text" name="phone_number" class="form-control" value="<?php echo e(old('phone_number')); ?>" placeholder="Enter Phone Number">
								<?php if($errors->has('phone_number')): ?>
									<span class="text-danger"><?php echo e($errors->first('phone_number')); ?></span>
								<?php endif; ?>
							</div>
							<label for="input-13" class="col-sm-2 col-form-label">Mobile Number<span class="text-danger">*</span></label>
							<div class="col-sm-4">
								<input type="text" name="mobile_number" class="form-control" value="<?php echo e(old('mobile_number')); ?>" placeholder="Enter Mobile Number">
								<?php if($errors->has('mobile_number')): ?>
									<span class="text-danger"><?php echo e($errors->first('mobile_number')); ?></span>
								<?php endif; ?>
							</div>
						</div>
						<div class="form-group row">
							<label for="input-12" class="col-sm-2 col-form-label">Address</label>
							<div class="col-sm-4">
								<textarea class="form-control" id="input-8" name="address" placeholder="Enter Address"><?php echo e(old('address')); ?></textarea>
							</div>
							<label for="input-13" class="col-sm-2 col-form-label">Country</label>
							<div class="col-sm-4">
								<select class="form-control" name="country" id="country">
									<option value="">Select Country</option>
									<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($country->id); ?>" <?php echo e((old("country") == $country->id ? "selected":"")); ?>><?php echo e($country->name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
						</div>
						<div class="form-group row">
							<label for="input-12" class="col-sm-2 col-form-label">State</label>
							<div class="col-sm-4">
								<select class="form-control" id="state" name="state" value="<?php echo e(old('state')); ?>">
									<option value="">Select State</option>
								</select>
							</div>
							<label for="input-13" class="col-sm-2 col-form-label">City</label>
							<div class="col-sm-4">
								<select class="form-control" id="city" name="city" value="<?php echo e(old('city')); ?>">
									<option value="">Select City</option>
								</select>
							</div>
						</div>
						<div class="form-group row">
							<label for="input-12" class="col-sm-2 col-form-label">Zip Code</label>
							<div class="col-sm-4">
								<input type="text" name="pincode" class="form-control" value="<?php echo e(old('pincode')); ?>" placeholder="Enter Zip Code">
							</div>
							<label for="input-11" class="col-sm-2 col-form-label">Expired Date</label>
							<div class="col-sm-4">
								<input type="text" id="datepicker" class="form-control" name="expired_date" value="<?php echo e(old('expired_date')); ?>" placeholder="Enter Expired Date">
							</div>
						</div>
						<div class="form-group row">
							<label for="input-13" class="col-sm-2 col-form-label">Transaction Fees %</label>
							<div class="col-sm-4">
								<input type="text" name="admin_commision" class="form-control" value="<?php echo e(old('admin_commision')); ?>" placeholder="Enter Admin Comission">
							</div>
							<label for="input-12" class="col-sm-2 col-form-label">Website link</label>
							<div class="col-sm-4">
								<input type="text" name="website_link" class="form-control" value="<?php echo e(old('website_link')); ?>" placeholder="Enter Website Link">
							</div>
						</div>
						<div class="form-group row">					
							<label for="input-13" class="col-sm-2 col-form-label">Status<span class="text-danger">*</span></label>
							<div class="col-sm-4">
								<select name="status" class="form-control">
									<option value="">Select Status</option>
									<option value="active" <?php if(old('status')=='active'): ?> selected="selected" <?php endif; ?>>Active</option>
									<option value="deactive" <?php if(old('status')=='deactive'): ?> selected="selected" <?php endif; ?>>Deactive</option>
								</select>
								<?php if($errors->has('status')): ?>
								<span class="text-danger"><?php echo e($errors->first('status')); ?></span>
								<?php endif; ?>
							</div>
							<label for="input-10" class="col-sm-2 col-form-label">Image</label>
	                        <div class="col-sm-4">
	                            <input type="file" class="form-control" name="image">
	                        </div>
						</div>
						<center>
							<div class="form-footer">
								<button type="submit" class="btn btn-success"><i class="fa fa-check-square-o"></i> SAVE</button>
								<a href="<?php echo e(url('admin/vendor')); ?>"><button type="button" class="btn btn-danger"><i class="fa fa-times"></i> CANCEL</button></a>
							</div>
						</center>
					</form>
                </div>
			</div>
		</div>
	</div>
</div>
<!--End Row--> 
<script>
$('#autoclose-datepicker').datepicker({
	autoclose: true,
	todayHighlight: true
});
</script>
<script type="text/javascript">

var countryID = "<?php echo e(old('country')); ?>";
var stateID = "<?php echo e(old('state')); ?>";
var cityID = "<?php echo e(old('city')); ?>";

$(function() {

	setTimeout(function(){ getState(); }, 500);
	setTimeout(function(){ getCity(); }, 500);

	$("#country").change(function() {
		countryID = $(this).val();
		getState();
	});

	$("#state").change(function() {
		stateID = $(this).val();
		getCity();
	});

	var date = new Date();
    date.setDate(date.getDate() + 1);
    $('#datepicker').datepicker({ 
        autoclose: true, 
        startDate: date,
        todayHighlight: true
    });

});

function getState(){
	if(countryID != ''){
		$.ajax({
			data: {
			"_token": "<?php echo e(csrf_token()); ?>"
			},
			url: "<?php echo e(url('/get-state')); ?>/"+countryID,
			type: "GET",
			dataType: 'json',
			success: function (data) {
				$('#state').empty();
				$.each(data, function(i, val) {
					$("#state").append('<option value=' +val.id + '>' + val.name + '</option>');
				});
				if($("#state option[value='"+stateID+"']").length > 0){
                    $('#state').val(stateID);
                }
			},
			error: function (data) {
			}
		});
	}else{
		$("#country").val('');
	}
}

function getCity(){
	if(stateID != ''){
		$.ajax({
			data: {
			"_token": "<?php echo e(csrf_token()); ?>"
			},
			url: "<?php echo e(url('/get-city')); ?>/"+stateID,
			type: "GET",
			dataType: 'json',
			success: function (data) {
				$('#city').empty();
				$.each(data, function(i, val) {
					$("#city").append('<option value=' +val.id + '>' + val.name + '</option>');
				});
				if($("#city option[value='"+cityID+"']").length > 0){
                    $('#city').val(cityID);
                }
			},
			error: function (data) {
			}
		});
	}else{
		$("#state").val('');
	}
}
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gtvmcmgwqds4/public_html/resources/views/admin/vendors/create.blade.php ENDPATH**/ ?>