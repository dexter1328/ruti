<?php $__env->startSection('content'); ?>
<?php if(session()->get('error')): ?>
	<div class="alert alert-danger alert-dismissible" role="alert">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<div class="alert-message">
			<span><strong>Error!</strong> <?php echo e(session()->get('error')); ?></span>
		</div>
	</div>
<?php endif; ?>
<?php if(session()->get('success')): ?>
	<div class="alert alert-success alert-dismissible" role="alert">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<div class="alert-icon">
			<i class="fa fa-check"></i>
		</div>
		<div class="alert-message">
			<span><strong>Success!</strong> <?php echo e(session()->get('success')); ?></span>
		</div>
	</div>
<?php endif; ?>
<div class="row">
	<div class="col-lg-12">
		<div class="card">
			<div class="card-header">
				<div class="row">
					<div class="col-3">
						<div class="left"><span>Active Plan(s)</span></div>
					</div>
					<div class="col-9">
					</div>
				</div>
			</div>
			<div class="card-body">
				<div class="table-responsive">
					<table id="example" class="table table-bordered">
						<thead>
							<tr>
								<th>Plan</th>
								<th>Description</th>
								<th>Start Date</th>
								<th>End Date</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($plan->membership->name); ?></td>
									<td><?php echo e($plan->membership->description); ?></td>
									
									<td><?php echo e(date('m/d/Y', strtotime($plan->start_date))); ?></td>
									<td><?php echo e(date('m/d/Y', strtotime($plan->end_date))); ?></td>
									<td class="action">
										<form id="cancelfrm_<?php echo e($plan->id); ?>" action="<?php echo e(route('supplier.cancel-subscription', $plan->id)); ?>" method="POST" class="cancel"  onsubmit="return confirm('Are you sure want to cancel the plan?');">
											<?php echo csrf_field(); ?>
											<?php echo method_field('DELETE'); ?>
											<button type="button" class="btn btn-block btn-outline-primary btn-rounded" onclick="cancelPlan('<?php echo e($plan->id); ?>');"><?php echo e($plan->is_cancelled == 'yes'? 'Cancelled':'Cancel'); ?></button>
										</form>
									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
				
					</table>
				</div>
			</div>
		</div>
	</div>
</div><!-- End Row-->

<script>
$(document).ready(function() {
	var table = $('#example').DataTable( {
		lengthChange: false,
			buttons: [
			{
				extend: 'copy',
				title: 'Notification List',
				exportOptions: {
					columns: [ 0, 1, 2, 3, 4]
				}
			},
			{
				extend: 'excelHtml5',
				title: 'Notification List',
				exportOptions: {
					columns: [ 0, 1, 2, 3, 4]
				}
			},
			{
				extend: 'pdfHtml5',
				title: 'Notification List',
				exportOptions: {
					columns: [ 0, 1, 2, 3, 4]
				}
			},
			{
				extend: 'print',
				title: 'Notification List',
				autoPrint: true,
				exportOptions: {
					columns: [ 0, 1, 2, 3, 4]
				}
			},
			'colvis'
		],
		columnDefs: [
			{ orderable: false, targets: 5 }
		]
	});

	table.buttons().container().appendTo( '#example_wrapper .col-md-6:eq(0)' );
});

function cancelPlan(id)
{
	$('#cancelfrm_'+id).submit();
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('supplier.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\work\ruti\resources\views/supplier/suppliers/active_plan.blade.php ENDPATH**/ ?>