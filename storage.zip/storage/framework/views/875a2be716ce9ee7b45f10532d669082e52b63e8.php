<?php $__env->startSection('content'); ?>
<?php if(session()->get('success')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
	<button type="button" class="close" data-dismiss="alert">×</button>
	<div class="alert-icon">
		<i class="fa fa-check"></i>
	</div>
	<div class="alert-message">
		<span><strong>Success!</strong> <?php echo e(session()->get('success')); ?></span>
	</div>
</div>
<?php endif; ?>
<div class="row">
	<div class="col-lg-12">
		<div class="card">
			<div class="card-header">
				<div class="left"><!-- <i class="fa fa-cog"></i> --><span>Settings</span></div>
			</div>
			<div class="card-body">
            	<div class="container-fluid">
					<form id="signupForm" method="post" action="<?php echo e(route('vendor.settings.store')); ?>" enctype="multipart/form-data">
						<?php echo csrf_field(); ?>
						<!-- <div class="form-group row">
							<label class="col-sm-12 col-form-label">Suspend Customer Account</label>
						</div> -->
						<div class="form-group row">
							<label for="input-13" class="col-sm-3 col-form-label">Inventory Update Reminder<span class="text-danger">*</span></label>
							<div class="col-sm-9">
								<div class="input-group mb-3">
									<select class="form-control" name="setting[inventory_update_reminder_day]">
										<option value="">Select Day</option>
										<?php $__currentLoopData = weekdays(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php $selected = '';
											if(isset($setting['inventory_update_reminder_day']) && $value == $setting['inventory_update_reminder_day']) {
												$selected = 'selected="selected"';
											} ?>
											<option value="<?php echo e($value); ?>" <?php echo e($selected); ?>><?php echo e($value); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
									<select class="form-control" name="setting[inventory_update_reminder_time]">
										<option value="">Select Time</option>
										<?php $__currentLoopData = vendor_store_hours(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php $selected = '';
											if(isset($setting['inventory_update_reminder_time']) && $time->format('H:i') == $setting['inventory_update_reminder_time']) {
												echo $selected = 'selected="selected"';
											} ?>
											<option value="<?php echo e($time->format('H:i')); ?>" <?php echo e($selected); ?>><?php echo e($time->format('H:i')); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
								<?php if($errors->has('setting.inventory_update_reminder_day') || $errors->has('setting.inventory_update_reminder_time')): ?> 
									<span class="text-danger">Inventory update reminder day and time fields are required.</span> 
								<?php endif; ?> 
							</div>
						</div>
						<?php if(vendor_has_permission(Auth::user()->role_id,'setting','write') ): ?>
						<center>
							<div class="form-footer">
								<button type="submit" class="btn btn-success"><i class="fa fa-check-square-o"></i> SAVE</button>
							</div>
						</center>
						<?php endif; ?>
					</form>
                </div>
			</div>
		</div>
	</div>
</div>
<!--End Row--> 
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('vendor.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gtvmcmgwqds4/public_html/resources/views/vendor/settings/index.blade.php ENDPATH**/ ?>