<?php $__env->startSection('content'); ?>
<style type="text/css">
	div#importModal {
	    width: 50%;
	    margin: 
	    0 auto;
	}
	.store-btn-right a,
	.store-btn-right button{width:100%;}
	.store-btn-right input.form-control {
	    padding: 2px;
	    border: 1px solid #003366;
	    position: relative;
	    top: 4px;
	}
</style>
<?php if(session()->get('success')): ?>
	<div class="alert alert-success alert-dismissible" role="alert">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<div class="alert-icon">
			<i class="fa fa-check"></i>
		</div>
		<div class="alert-message">
			<span><strong>Success!</strong> <?php echo e(session()->get('success')); ?></span>
		</div>
	</div>
<?php endif; ?>
<?php if(session()->get('error-data')): ?>
 	<input type="hidden" id="error" value="<?php echo e(session()->get('error-data')); ?>"></span>
<?php endif; ?>
<?php if(session()->get('success-data')): ?>
	<!-- <div class="alert alert-success alert-dismissible" role="alert">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<div class="alert-icon">
			<i class="fa fa-check"></i>
		</div>
		<div class="alert-message">
			<span><strong>Success!</strong> <?php echo e(session()->get('success-data')['message']); ?></span>
		</div>
	</div> -->
	<?php if(!empty(session()->get('success-data')['emails'])): ?>
		<div class="alert alert-danger alert-dismissible" role="alert">
			<button type="button" class="close" data-dismiss="alert">×</button>
			<div class="alert-message">
				<span><strong>Error!</strong> These email are already exist.</span>
				<ul>
					<?php $__currentLoopData = session()->get('success-data')['emails']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($value); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
		</div>
	<?php else: ?>
		<div class="alert alert-success alert-dismissible" role="alert">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<div class="alert-icon">
			<i class="fa fa-check"></i>
		</div>
		<div class="alert-message">
			<span><strong>Success!</strong> <?php echo e(session()->get('success-data')['message']); ?></span>
		</div>
	</div>
	<?php endif; ?>
<?php endif; ?>
<div class="success-alert" style="display:none;"></div>
<div class="row">
	<div class="col-lg-12">
		<div class="card">
			<div class="card-header">
				<div class="row">
					<div class="col-3">
						<div class="left"><!-- <i class="fa fa-product-hunt"></i> --><span>Vendor Stores</span></div>
					</div>
					<div class="col-9">
						<div class="store-btn-right"> 
		                	<div class="row">   
		                		<div class="col-xs-12 col-sm-3">
		                			<a href="<?php echo e(url('/public/ezsiop-store-import.csv')); ?>" download="sample-store.csv" class="download-csv">Download Sample CSV</a>
		                		</div>
		                      	<div class="col-xs-12 col-sm-3">
		                      		<button class="btn btn-outline-primary btn-sm waves-effect waves-light m-1" data-toggle="modal" data-target="#importModal"><span class="name">Import</span></button>
		                        </div>
		                        <div class="col-xs-12 col-sm-3">
		                      		<a href="<?php echo e(url('admin/vendor_store/export/store')); ?>" class="btn btn-outline-primary btn-sm waves-effect waves-light m-1"><span class="name">Export</span></a>
		                        </div>
		                        <div class="col-xs-12 col-sm-3">
		                        	<a href="<?php echo e(route('vendor_store.create')); ?>" class="btn btn-outline-primary btn-sm waves-effect waves-light m-1" title="Add Store">
		                            <!-- <i class="fa fa-product-hunt" style="font-size:15px;"></i> --> <span class="name">Add Store</span>
		                        </a>
		                        </div>
							</div>
						</div>
					</div>
				</div>
				<!-- <div class="left"><span>Vendor Stores</span></div>
				<div class="float-sm-right">        
					<a style="padding-bottom: 3px; padding-top: 4px;" href="<?php echo e(route('vendor_store.create')); ?>" class="btn btn-outline-primary btn-sm waves-effect waves-light m-1" title="Add Store">
						<span class="name">Add Store</span>
					</a>
				</div> -->
			</div>
			<div class="card-body">
				<div class="table-responsive">
					<table id="example" class="table table-bordered">
						<thead>
							<tr>
								<th>#</th>
								<th>Vendor</th>
								<th>Store Name</th>
								<th>Branch Admin</th>
								<th>Phone No</th>
								<th>Email</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $vendor_stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$vendor_store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td ><?php echo e($key+1); ?></td>
									<td><?php echo e($vendor_store->vendor_name); ?></td>
									<td ><?php echo e($vendor_store->name); ?></td>
									<td ><?php echo e($vendor_store->branch_admin); ?></td>
									<td ><?php echo e($vendor_store->phone_number); ?></td>
									<td ><?php echo e($vendor_store->email); ?></td>
									<td class="action">
										<form id="deletefrm_<?php echo e($vendor_store->id); ?>" action="<?php echo e(route('vendor_store.destroy', $vendor_store->id)); ?>" method="POST" class="delete"  onsubmit="return confirm('Are you sure?');">
											<?php echo csrf_field(); ?>
											<?php echo method_field('DELETE'); ?>

											<a href="<?php echo e(route('vendor_store.edit', $vendor_store->id)); ?>" class="edit" data-toggle="tooltip" data-placement="bottom" title="Edit Store">
												<i class="icon-note icons"></i>
											</a>

											<a href="javascript:void(0);" onclick="deleteRow('<?php echo e($vendor_store->id); ?>')" data-toggle="tooltip" data-placement="bottom" title="Delete Store">
												<i class="icon-trash icons"></i>
											</a>

											<a href="javascript:void(0);" onclick="changeStatus('<?php echo e($vendor_store->id); ?>')" >
											 	<i class="fa fa-circle status_<?php echo e($vendor_store->id); ?>" style="<?php if($vendor_store->status=='enable'): ?>color:#009933;<?php else: ?> color: #ff0000;<?php endif; ?>" id="active_<?php echo e($vendor_store->id); ?>" data-toggle="tooltip" data-placement="bottom" title="Change Status"></i>
											</a>
										</form>
									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
						<tfoot>
							<tr>
								<th >#</th>
								<th >Branch Admin</th>
								<th>Vendor</th>
								<th >Name</th>
								<th >Phone No</th>
								<th >Email</th>
								<th >Action</th>
							</tr>
						</tfoot>
					</table>
				</div>
			</div>
		</div>
	</div>
</div><!-- End Row-->
<!-- import modal -->
<div class="modal fade" id="importModal">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Import Store</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
			<div id="error"></div>
				<form method="post" action="<?php echo e(url('admin/vendor_store/import-store')); ?>" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
					<div class="form-group">
						<label for="input-1">Vendor<span class="text-danger">*</span></label>
						<select name="vendor" class="form-control" id="vendor">
                                <option value="">Select Vendor</option>
                                <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($vendor->id); ?>" <?php echo e((old("vendor") == $vendor->id ? "selected":"")); ?>><?php echo e($vendor->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <span class="text-danger" id="vendor_preview_error"></span>
                        <?php if($errors->has('vendor')): ?> 
                            <span class="text-danger" id="vendor_error"><?php echo e($errors->first('vendor')); ?></span>
                    	<?php endif; ?> 
					</div>
					<div class="form-group">
						<label>File<span class="text-danger">*</span></label>
                        <input type="file" name="import_file" class="form-control">
                        <?php if($errors->has('import_file')): ?> 
                        	<span class="text-danger"><?php echo e($errors->first('import_file')); ?></span> 
                        <?php endif; ?> 
					</div>
					<div class="form-group">
						<button type="submit" class="btn btn-primary px-5" id="btnImport">Submit</button>
						<span id="processing" style="display: none;">Processing...</span>
					</div>
				</form> 
			</div>
		</div>
	</div>
</div>
<!-- import modal -->
<script>
$(document).ready(function() {
	// validation error of import
	var errors = '<?php echo $errors; ?>';
	var obj = $.parseJSON(errors);

	if(!jQuery.isEmptyObject(obj) || $('#error').val() != ''){
		$('#importModal').modal('show');
	}
	var table = $('#example').DataTable( {
		lengthChange: false,
				buttons: [
			{
				extend: 'copy',
				title: 'Store List',
				exportOptions: {
				columns: [ 0, 1, 2, 3, 4, 5]
				}
			},
			{
				extend: 'excelHtml5',
				title: 'Store List',
				exportOptions: {
				columns: [ 0, 1, 2, 3, 4, 5]
				}
			},
			{
				extend: 'pdfHtml5',
				title: 'Store List',
				exportOptions: {
				columns: [ 0, 1, 2, 3, 4, 5]
				}
			},
			{
				extend: 'print',
				title: 'Store List',
				autoPrint: true,
				exportOptions: {
				columns: [ 0, 1, 2, 3, 4, 5]
				}
			},
			'colvis'
		],
		//columnDefs: [
			//{ "orderable": false, "targets": 6 }
		//]
		columnDefs: [
            { width: "4%", targets: 0 },
            { width: "17%", targets: 1 },
            { width: "14%", targets: 2 },
            { width: "15%", targets: 3 },
            { width: "14%", targets: 4 },
            { width: "23%", targets: 5 },
            { width: "13%","orderable": false, targets: 6 },
        ],
        fixedColumns: true
	});

	table.buttons().container()
	.appendTo( '#example_wrapper .col-md-6:eq(0)' );
} );

function deleteRow(id)
{   
	$('#deletefrm_'+id).submit();
}

function changeStatus(id) {
    $.ajax({
        data: {
        "_token": "<?php echo e(csrf_token()); ?>",
        "id": id
        },
        url: "<?php echo e(url('admin/vendor_store')); ?>/"+id,
        type: "GET",
        dataType: 'json',
        success: function (data) {
        	var status = '';
            // $('.status_'+id).attr('title',data);
            if(data == 'enable'){
            	status = 'enabled';
                $('.status_'+id).css('color','#009933');
                
            }else{
            	status = 'disabled';
                $('.status_'+id).css('color','#ff0000');
            }
            $('.success-alert').show();
			var suc_str = '';
			suc_str += '<div class="alert alert-success alert-dismissible" role="alert">';
			suc_str +='<button type="button" class="close" data-dismiss="alert">×</button>';
			suc_str +='<div class="alert-icon"><i class="fa fa-check"></i></div>';
			suc_str +='<div class="alert-message"><span><strong>Success!</strong> Store has been '+status+'.</span></div>';
			suc_str +='</div>';
			$('.success-alert').html(suc_str);
        },
        error: function (data) {
        }
    });
}
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gtvmcmgwqds4/public_html/resources/views/admin/vendor_store/index.blade.php ENDPATH**/ ?>