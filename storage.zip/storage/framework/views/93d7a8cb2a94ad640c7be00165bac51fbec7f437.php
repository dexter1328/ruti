 <center>
      <img src="<?php echo e(asset('public/images/logo-icon-xx.png')); ?>" style="width:250px; height: auto;border: none; display: block; -ms-interpolation-mode: bicubic;">
</center>

<p>Hi Admin,</p>

<p>New Supplier Signup in Nature Checkout</p>
<a href="<?php echo e(route('supplier.edit', $id)); ?>" class="edit" data-toggle="tooltip" data-placement="bottom" title="Edit Supplier">
  To view supplier refer this link
</a>
<br>
<table class="table table-bordered" style="margin-top:20px;" cellpadding="2" cellspacing="5">
    <tbody>
      	<tr>
	        <td><b>Name</b></td>
	        <td><?php echo e($name); ?></td>
      	</tr>
      	<tr>
	        <td><b>Email</b></td>
	        <td><?php echo e($email); ?></td>
      	</tr>
      	<?php if(!empty($mobile_number)): ?>
      	<tr>
	        <td><b>Mobile No</b></td>
	        <td><?php echo e($mobile_number); ?></td>
      	</tr>
      	<?php endif; ?>
      	<?php if(!empty($phone_number)): ?>
      	<tr>
	        <td><b>Phone Number</b></td>
	        <td><?php echo e($phone_number); ?></td>
      	</tr>
      	<?php endif; ?>
      	<?php if(!empty($address)): ?>
      	<tr>
	        <td><b>Address</b></td>
	        <td><?php echo e($address); ?></td>
      	</tr>
      	<?php endif; ?>
      	<?php if($country != NULL): ?>
      	<tr>
	        <td><b>Country</b></td>
	        <td><?php echo e($country); ?></td>
      	</tr>
      	<?php endif; ?>
      	<?php if($state != NULL): ?>
      	<tr>
	        <td><b>State</b></td>
	        <td><?php echo e($state); ?></td>
      	</tr>
      	<?php endif; ?>
      	<?php if($city != NULL): ?>
      	<tr>
	        <td><b>City</b></td>
	        <td><?php echo e($city); ?></td>
      	</tr>
      	<?php endif; ?>
      	<?php if(!empty($pincode)): ?>
      	<tr>
	        <td><b>Zip Code</b></td>
	        <td><?php echo e($pincode); ?></td>
      	</tr>
      	<?php endif; ?>

    </tbody>
	<a href="<?php echo e(url('admin/supplier/approve',$id)); ?>">approve this supplier</a>
  </table>
  <br><br>
Regards,<br>
Nature Checkout Team

<?php /**PATH C:\xampp\htdocs\work\ruti\resources\views/admin/suppliers/supplier_signup_mail.blade.php ENDPATH**/ ?>