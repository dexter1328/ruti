 <center>
      <img src="<?php echo e(asset('public/images/logo-icon-xx.png')); ?>" style="width:250px; height: auto;border: none; display: block; -ms-interpolation-mode: bicubic;">
</center>

<div style="margin:30px;"><?php echo $messageBody; ?></div>
<?php /**PATH C:\xampp\htdocs\work\ruti\resources\views/admin/suppliers/supplier_success.blade.php ENDPATH**/ ?>