<!-- Main Content -->
<?php $__env->startSection('content'); ?>

<div class="card-body">
    <div class="card-content p-2">
        <div class="card-title text-uppercase pb-2">Reset Password</div>
        <?php if(session('status')): ?>
            <div class="alert alert-success alert-dismissible" role="alert">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <div class="alert-icon">
                    <i class="fa fa-check"></i>
                </div>
                <div class="alert-message">
                    <span><strong>Success!</strong> <?php echo e(session('status')); ?></span>
                </div>
            </div>
        <?php endif; ?>

       <!--  <?php if(session('status')): ?>
            
                <div class="pb-2 alert-message">
                    <span><strong>Success!</strong> <?php echo e(session('status')); ?></span>
                </div>
            
        <?php endif; ?> -->
        <p class="pb-2">Please enter your email address. You will receive a link to create a new password via email.</p>
        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/vendor/password/email')); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="email" class="">Email Address</label>
                <div class="position-relative has-icon-right">
                    <input type="email" id="email" name="email" class="form-control input-shadow <?php echo e($errors->has('email') ? 'error' : ''); ?>" value="<?php echo e(old('email')); ?>" placeholder="Email Address">
                    <div class="form-control-position">
                        <i class="icon-envelope-open"></i>
                    </div>
                    <?php if($errors->has('email')): ?>
                        <label class="error"><?php echo e($errors->first('email')); ?></label>
                    <?php endif; ?>
                </div>
            </div>

            <button class="btn btn-warning btn-block mt-3">Reset Password</button>
        </form>
    </div>
</div>
<div class="card-footer text-center py-3">
    <p class="text-dark mb-0">Return to the <a href="<?php echo e(route('vendor.login')); ?>"> Sign In</a></p>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('vendor.layout.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gtvmcmgwqds4/public_html/resources/views/vendor/auth/passwords/email.blade.php ENDPATH**/ ?>