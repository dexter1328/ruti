<?php $__env->startSection('content'); ?>
    <style type="text/css">
        .btn-outline-primary:not(:disabled):not(.disabled).active,
        .btn-outline-primary:not(:disabled):not(.disabled):active,
        .show>.btn-outline-primary.dropdown-toggle {
            color: #fff !important;
            background-color: #ec6224 !important;
            border-color: #ec6224 !important;
        }

        div#cardModal {
            width: 50%;
            margin: 0 auto;
        }

        div#thnksModal {
            width: 45%;
            margin: 0 auto;
        }
    </style>
   <?php if(session()->get('success')): ?>
   <div class="alert alert-success alert-dismissible" role="alert">
       <button type="button" class="close" data-dismiss="alert">×</button>
       <div class="alert-icon">
           <i class="fa fa-check"></i>
       </div>
       <div class="alert-message">
           <span><strong>Success!</strong> <?php echo e(session()->get('success')); ?></span>
       </div>
   </div>
   <?php elseif(session()->get('error')): ?>
   <div class="alert alert-danger alert-dismissible" role="alert">
       <button type="button" class="close" data-dismiss="alert">×</button>
       <div class="alert-icon">
           <i class="fa fa-check"></i>
       </div>
       <div class="alert-message">
           <span><strong>Error!</strong> <?php echo e(session()->get('error')); ?></span>
       </div>
   </div>
   <?php endif; ?>
    <?php
        //echo '<pre>';
        /*foreach($features as $key => $feature){
        	print_r($feature['label']);
        }*/
        //print_r($features);
        //print_r($memberships->toArray());
        //echo '</pre>';
        //exit();
    ?>
    <div id="currentPlanAlert" style="display: none;">
        <div class="alert alert-dark" role="alert">
            <div class="alert-message" id="currentPlanMsg">
            </div>
        </div>
    </div>
    <div class="row">
        
        <div class="container">
            <div class="card-deck mb-3 text-center">
				<?php $__currentLoopData = $memberships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membership): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mb-4 box-shadow">
                    <div class="card-header">
                        <h4 class="my-0 font-weight-normal"><?php echo e($membership->name); ?></h4>
                    </div>
                    <div class="card-body">
                        <h1 class="card-title pricing-card-title">$<?php echo e($membership->monthMembershipItem->price); ?><small class="text-muted">/ month</small></h1>
                        <h1 class="card-title pricing-card-title">$<?php echo e($membership->yearMembershipItem->price); ?><small class="text-muted">/ year</small></h1>
                        <ul class="list-unstyled mt-3 mb-4">
                            <li><?php echo e($membership->description); ?></li>

                        </ul>
                        <a type="button" href="<?php echo e(route('supplier.payment-page',$membership->id)); ?>" class="btn btn-lg btn-block btn-outline-primary">Buy now!</a>
                    </div>
                </div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('supplier.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\work\ruti\resources\views/supplier/suppliers/choose_plan.blade.php ENDPATH**/ ?>