<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-lg-12">
		<div class="card">
			<div class="card-header">
				<div class="left"><!-- <i class="fa fa-address-book-o"></i> --><span>Add Admin</span></div>
			</div>
			<div class="card-body">
            	<div class="container-fluid">
					<form id="signupForm" method="post" action="<?php echo e(route('admins.store')); ?>" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
					<div class="form-group row">
						<label for="input-10" class="col-sm-2 col-form-label">Name<span class="text-danger">*</span></label>
						<div class="col-sm-4">
							<input type="text" class="form-control" id="input-10" name="name" placeholder="Enter Name" value="<?php echo e(old('name')); ?>">
							<?php if($errors->has('name')): ?>
								<span class="text-danger"><?php echo e($errors->first('name')); ?></span>
							<?php endif; ?>
						</div>
						<label for="input-10" class="col-sm-2 col-form-label">Email<span class="text-danger">*</span></label>
						<div class="col-sm-4">
							<input type="email" class="form-control" id="input-11" name="email" placeholder="Enter Email" value="<?php echo e(old('email')); ?>">
							<?php if($errors->has('email')): ?>
								<span class="text-danger"><?php echo e($errors->first('email')); ?></span>
							<?php endif; ?>
						</div>
					</div>
					<div class="form-group row">
						<label for="input-13" class="col-sm-2 col-form-label">Password<span class="text-danger">*</span></label>
						<div class="col-sm-4">
							<input type="password" class="form-control" id="input-13" name="password" placeholder="Enter password" value="<?php echo e(old('password')); ?>">
							<?php if($errors->has('password')): ?>
								<span class="text-danger"><?php echo e($errors->first('password')); ?></span>
							<?php endif; ?>
						</div>
						<label for="input-12" class="col-sm-2 col-form-label">Image</label>
						<div class="col-sm-4">
							<input type="file" class="form-control" id="input-8" name="image" value="<?php echo e(old('image')); ?>">
							<?php if($errors->has('image')): ?>
								<span class="text-danger"><?php echo e($errors->first('image')); ?></span>
							<?php endif; ?>
						</div>
					</div>
					<div class="form-group row">
						<label for="role_id" class="col-sm-2 col-form-label">Role<span class="text-danger">*</span></label>
						<div class="col-sm-4">
							<?php $roles = DB::table('admin_roles')->get(); ?>
							<select class="form-control" id="role_id" name="role_id">
								<option value="">Select Role</option>
								<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php $selected = ($role->id == old('role_id') ? 'selected="selected"' : ''); ?>
									<option value="<?php echo e($role->id); ?>" <?php echo e($selected); ?>><?php echo e($role->role_name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
							<?php if($errors->has('role_id')): ?>
								<span class="text-danger"><?php echo e($errors->first('role_id')); ?></span>
							<?php endif; ?>
						</div>
						<label for="input-13" class="col-sm-2 col-form-label">Status<span class="text-danger">*</span></label>
						<div class="col-sm-4">
							<select name="status" class="form-control">
								<option value="">Select Status</option>
								<option value="active" <?php if(old('status')=='active'): ?> selected="selected" <?php endif; ?>>Active</option>
								<option value="deactive" <?php if(old('status')=='deactive'): ?> selected="selected" <?php endif; ?>>Deactive</option>
							</select>
							<?php if($errors->has('status')): ?>
								<span class="text-danger"><?php echo e($errors->first('status')); ?></span>
							<?php endif; ?>
						</div>
					</div>
					<center>
						<div class="form-footer">
							<button type="submit" class="btn btn-success"><i class="fa fa-check-square-o"></i> SAVE</button>
							<a href="<?php echo e(url('admin/admins')); ?>"><button type="button" class="btn btn-danger"><i class="fa fa-times"></i> CANCEL</button></a>
						</div>
					</center>
				</form>
                </div>
			</div>
		</div>
	</div>
</div>
<!--End Row--> 

<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script> 

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gtvmcmgwqds4/public_html/resources/views/admin/admin/create.blade.php ENDPATH**/ ?>