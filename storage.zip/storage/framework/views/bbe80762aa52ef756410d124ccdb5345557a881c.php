<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading p-3 w-100"><h4 class='m-auto'> Register Your Account </h4></div>
                <!-- <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/vendor/register')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-4 control-label">Name</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>">

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label for="password" class="col-md-4 control-label">Password</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password">

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
                            <label for="password-confirm" class="col-md-4 control-label">Confirm Password</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation">

                                <?php if($errors->has('password_confirmation')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Register
                                </button>
                            </div>
                        </div>
                    </form>
                </div> -->
                <div class="font-para SignUPform col-lg-12 col-md-12 col-sm-12">
                        <form id="signupForm" method="post" action="<?php echo e(url('/w2bcustomer/register')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="input-12" class="col-form-label">First Name<span class="text-danger">*</span></label>
                                <div>
                                    <input type="text" name="first_name" class="form-control" value="<?php echo e(old('first_name')); ?>" placeholder="Enter First Name">
                                    <?php if($errors->has('first_name')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('first_name')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <label for="input-12" class="col-form-label">Last Name<span class="text-danger">*</span></label>
                                <div>
                                    <input type="text" name="last_name" class="form-control" value="<?php echo e(old('last_name')); ?>" placeholder="Enter Last Name">
                                    <?php if($errors->has('last_name')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('last_name')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="input-12" class="col-form-label">Phone No.<span class="text-danger">*</span></label>
                                <div>
                                    <input type="text" name="mobile" class="form-control" value="<?php echo e(old('mobile')); ?>" placeholder="Enter Phone Number">
                                    <?php if($errors->has('mobile')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('mobile')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <label for="input-12" class="col-form-label">Email<span class="text-danger">*</span></label>
                                <div>
                                    <input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>" placeholder="Enter E-mail">
                                    <?php if($errors->has('email')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="input-13" class="col-form-label">Password<span class="text-danger">*</span></label>
                                <div>
                                    <input type="password" id="password" name="password" class="form-control" value="<?php echo e(old('password')); ?>" placeholder="Enter Password">
                                    <span toggle="#password" class="fa fa-eye field-icon toggle-password"></span>
                                    <?php if($errors->has('password')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <label for="input-13" class="col-form-label">Confirm Password<span class="text-danger">*</span></label>
                                <div>
                                    <input type="password" id="password_confirmation" name="password_confirmation" class="form-control" value="<?php echo e(old('password_confirmation')); ?>" placeholder="Enter Confirm Password">
                                    <span class="confirm-check fa"></span>
                                    <?php if($errors->has('password_confirmation')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('password_confirmation')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group AcceptCheckbox">
                                <div class="">
                                    <input type="checkbox" id="terms_condition" name="terms_condition" value="yes"<?php echo e(old('terms_condition') == 'yes' ? 'checked' : ''); ?> class="">

                                    <label for="terms_condition"> I've read and accept the <a href="<?php echo e(url('/privacy-policy')); ?>" style="color:navy !important;text-decoration: revert;">privacy</a> and <a href="<?php echo e(url('/terms-condition')); ?>" style="color:navy !important;text-decoration: revert;">terms.</a></label><br>
                                    <?php if($errors->has('terms_condition')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('terms_condition')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class='col-sm-10'>
                                <?php echo app('captcha')->display(); ?>

                                <?php if($errors->has('g-recaptcha-response')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('g-recaptcha-response')); ?>

                                    </span>
                                <?php endif; ?>
                                </div>
                            </div>
                            <center>
                                <div class="form-footer w-100 px-4">
                                    <button type="submit" class="btn btn-primary sign_up_btn w-100"> SignUp<ig/button>
                                    <button type="submit" class="btn mt-3 btn-light sign_up_btn w-50"> Register with Google<ig/button>
                                    <button type="reset" class="btn mt-3 btn-primary w-50"> Register with Facebook</button>
                                    <hr>
                                    <button type="reset" class="btn btn-success w-100"> Sign up as Customer</button>
                                </div>
                            </center>
                        </form>
                    </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.layout.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\work\ruti\resources\views/vendor/auth/register.blade.php ENDPATH**/ ?>