<?php $__env->startSection('content'); ?>

<!--breadcrumbs area start-->
<div class="mt-70">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb_content">
                   <h3>Cart</h3>
                    <ul>
                        <li><a href="index.html">home</a></li>
                        <li>Shopping Cart</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!--breadcrumbs area end-->
<?php if(session('success')): ?>
<div class="container alert alert-success text-center">
  <?php echo e(session('success')); ?>

</div>
<?php endif; ?>
 <!--shopping cart area start -->

 <!--shopping cart area end -->

<!-- new shopping cart -->

<div class='row w-100 justify-content-between ml-0 p-5'>
    <div class="col-12 order_main px-0 border">
        <div class='d-flex justify-content-between p-3 border orders_header'>
            <div class='orders_header1 d-flex justify-content-between w-100'>
                <div class='width-20'>
                    Product
                </div>
                <div class='width-20'>
                    Product Name
                </div>
                <div class='width-20'>
                    Quantity
                </div>
                <div class='width-20'>
                   Price
                </div>
                <div  class='width-20'>
                   Total Price
                </div>
            </div>
        </div>
        <div class="orders_body p-3">
            <?php $total = 0 ?>
            <?php if(session('cart')): ?>
            <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sku => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $total += $details['retail_price'] * $details['quantity'] ?>

            <div data-id="<?php echo e($sku); ?>" class='w-100 justify-content-between order_tab d-flex mt-4 sku-class'>

                <div class='width-20'>
                    <a role="button" class="remove-from-cart"><i class="fa fa-trash-o"></i></a>
                    <img src="<?php echo e($details['original_image_url']); ?>" class='table_product_image ml-4' alt="">
                </div>
                <div class='px-2 width-20 image_title'>
                    <span><?php echo e(Str::limit($details['title'], 30)); ?></span>
                    <br>
                    
                </div>
                <div class='width-20'>
                    <span><label>Quantity</label> <input min="1" max="100" class="quantity update-cart" value="<?php echo e($details['quantity']); ?>" type="number"></span>
                </div>
                <div class='width-20'>
                    <span>$<?php echo e(number_format((float)$details['retail_price'], 2, '.', '')); ?></span>
                </div>
                <div class='width-20'>
                    <span>$<?php echo e(number_format((float)$details['retail_price'] * $details['quantity'], 2, '.', '')); ?></span>
                </div>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
        <div class="orders_footer border-top text-right">
        <a class='text-danger pr-3' href="<?php echo e(route('remove-everything')); ?>">Remove Everything</a>
        </div>
    </div>
    <div class="coupon_area mt-5 col-12">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="coupon_code right">
                            <h3>Cart Totals</h3>
                            <div class="coupon_inner">
                               <div class="cart_subtotal">
                                   <p>Subtotal</p>
                                   <p class="cart_amount">$<?php echo e(number_format((float)$total, 2, '.', '')); ?></p>
                               </div>
                               <hr>
                               

                               <div class="cart_subtotal">
                                   <p>Total</p>
                                   <p class="cart_amount">$<?php echo e(number_format((float)$total, 2, '.', '')); ?></p>
                               </div>
                               <div class="checkout_btn">
                                    <a href="<?php echo e(route('product-shop')); ?>">Back to Shopping</a>
                                   <a href="<?php echo e(route('product-checkout')); ?>">Proceed to Checkout</a>
                               </div>
                               
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class='main_parent_div border col-lg-8 col-sm-12 m-auto px-0'>
                <h3 class='sections_coupons_header like_products_heading p-2' >Products You may like</h3>
                <div class='p-3 d-flex products_inner'>
                    <?php $__currentLoopData = $suggested_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class='more_products ml-2 py-2 px-4'>
                        <a href="<?php echo e(route('product-detail',$p->sku)); ?>">
                        <img src="<?php echo e($p->original_image_url); ?>" class='more_products_img'  alt="">
                        </a>
                        <div class='products_title'>
                            <h5><a href="<?php echo e(route('product-detail',$p->sku)); ?>"><?php echo e(Str::limit($p->title, 20)); ?></a></h5>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
            </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scriptss'); ?>

<script type="text/javascript">

    $(".update-cart").change(function (e) {
        e.preventDefault();

        var ele = $(this);

        $.ajax({
            url: '<?php echo e(route('update.cart')); ?>',
            method: "patch",
            data: {
                _token: '<?php echo e(csrf_token()); ?>',
                sku: ele.parents(".sku-class").attr("data-id"),
                quantity: ele.parents(".sku-class").find(".quantity").val()
            },
            success: function (response) {
               window.location.reload();
            }
        });
    });

    $(".remove-from-cart").click(function (e) {
        e.preventDefault();

        var ele = $(this);

        if(confirm("Are you sure want to remove?")) {
            $.ajax({
                url: '<?php echo e(route('remove.from.cart')); ?>',
                method: "DELETE",
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    sku: ele.parents(".sku-class").attr("data-id")
                },
                success: function (response) {
                    window.location.reload();
                }
            });
        }
    });

    $("document").ready(function(){
        setTimeout(function() {
        $('.alert-success').fadeOut('fast');
        }, 3000);

    });

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front_end.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\work\ruti\resources\views/front_end/cart.blade.php ENDPATH**/ ?>