<?php $__env->startSection('content'); ?>

<?php if(session()->get('success')): ?>
	<div class="alert alert-success alert-dismissible" role="alert">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<div class="alert-icon">
			<i class="fa fa-check"></i>
		</div>
		<div class="alert-message">
			<span><strong>Success!</strong> <?php echo e(session()->get('success')); ?></span>
		</div>
	</div>
<?php endif; ?>
<div class="success-alert" style="display:none;"></div>
<div class="row">
	<div class="col-lg-12">
		<div class="card">
			<div class="card-header">
				<div class="left"><!-- <i class="fa fa-group"></i> --><span>Wholesale2b Orders</span></div>
				<div class="float-sm-right">
					<?php /* ?>
					<a style="padding-bottom: 3px; padding-top: 4px;" href="<?php echo e(route('membership.create', $type)); ?>" class="btn btn-outline-primary btn-sm waves-effect waves-light m-1" title="Add Membership">
						<!-- <i class="fa fa-group" style="font-size: 15px;"></i> --> <span class="name">Add Membership</span>
					<?php */ ?>
					</a>
				</div>
			</div>
			<div class="card-body">
				<div class="table-responsive">
					<table id="example" class="table table-bordered">
						<thead>
							<tr>
								<th>#</th>
								<th style="width: 15%">Order No</th>
								<th style="width: 25%">Customer Name</th>
								<th>Total Price</th>
								<th>Order Notes</th>
								<th>Status</th>
								<th>Products</th>
								<th>Actions</th>
							</tr>
						</thead>
						<tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

								<tr>
									<td><?php echo e($loop->iteration); ?></td>
									<td><?php echo e($order->order_id); ?></td>
									<td><?php echo e($order->first_name); ?> <?php echo e($order->last_name); ?></td>
									<td><?php echo e($order->total_price); ?></td>
									<td><?php echo e($order->order_notes); ?></td>
									<td><?php echo e($order->status); ?></td>
									<td><a href="<?php echo e(route('admin.wborderedproducts',$order->order_id)); ?>" class="btn btn-info">Show</a></td>
									<td class="w-20">
                                        <?php if($order->status == "processing"): ?>
                                            <select class="form-control" onchange="updateStatus1(<?php echo e($order->id); ?>, $(this))" >
                                            <option value="processing" selected> processing</option>
                                            <option value="shipped" > shipped</option>
                                            <option value="delivered" > Delivered</option>
                                            <option value="cancelled" > Cancel</option>
                                            </select>
                                         <?php elseif($order->status == "shipped"): ?>
                                            <select class="form-control" onchange="updateStatus1(<?php echo e($order->id); ?>, $(this))" >
                                            <option value="processing" > processing</option>
                                            <option value="shipped" selected> shipped</option>
                                            <option value="delivered" > Delivered</option>
                                            <option value="cancelled" > Cancel</option>

                                            </select>
                                        <?php elseif($order->status == "delivered"): ?>
                                            <select class="form-control" onchange="updateStatus1(<?php echo e($order->id); ?>, $(this))" >
                                            <option value="processing" > processing</option>
                                            <option value="shipped" > shipped</option>
                                            <option value="delivered" selected> Delivered</option>
                                            <option value="cancelled" > Cancel</option>

                                            </select>
                                         <?php else: ?>
                                            <select class="form-control" onchange="updateStatus1(<?php echo e($order->id); ?>, $(this))" >
                                            <option value="processing" > processing</option>
                                            <option value="shipped" > shipped</option>
                                            <option value="delivered" > Delivered</option>
                                            <option value="cancelled" selected> Cancel</option>

                                            </select>

                                        <?php endif; ?>
                                    </td>

								</tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
						<tfoot>
							<tr>
								<th>#</th>
								<th style="width: 15%">Order No</th>
								<th style="width: 25%">Customer Name</th>
								<th>Total Price</th>
								<th>Order Notes</th>
								<th>Status</th>
								<th>Products</th>
								<th>Actions</th>
							</tr>
						</tfoot>
					</table>
				</div>
			</div>
		</div>
	</div>
</div><!-- End Row-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts1'); ?>
<script>
    $(document).ready(function() {
    var table = $('#example').DataTable( {
        lengthChange: false,
        buttons: [ 'copy', 'excel', 'pdf', 'colvis' ]
    } );
 
    table.buttons().container()
        .appendTo( '#example_wrapper .col-md-6:eq(0)' );
} );
</script>

<script>
       function updateStatus1(id,$this) {

$.ajax({
           url: "<?php echo e(url('/admin/wborder/status')); ?>/"+id+'/'+$this.val(),


}).done(function(res) {
console.log(res)
location.reload();
});
}

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\work\ruti\resources\views/admin/wb_products/order.blade.php ENDPATH**/ ?>