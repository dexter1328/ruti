<?php $__env->startSection('content'); ?>
<div class="card-body">
    <div class="card-content p-2">
        <div class="text-center">
            <img src="<?php echo e(asset('public/images/logo-icon-xx.png')); ?>" alt="logo icon">
        </div>
        <div class="card-title text-uppercase text-center py-3">Admin Sign In</div>
        <form role="form" method="POST" action="<?php echo e(url('/admin/login')); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="email" class="sr-only">E-Mail Address</label>
                <div class="position-relative has-icon-right">
                    <input type="email" id="email" class="form-control input-shadow <?php echo e($errors->has('email') ? 'error' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="E-Mail Address" autofocus>
                    <div class="form-control-position">
                        <i class="icon-user"></i>
                    </div>
                    <?php if($errors->has('email')): ?>
                        <label class="error"><?php echo e($errors->first('email')); ?></label>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group">
                <label for="password" class="sr-only">Password</label>
                <div class="position-relative has-icon-right">
                    <input type="password" id="password" class="form-control input-shadow <?php echo e($errors->has('password') ? 'error' : ''); ?>" name="password" placeholder="Password">
                    <div class="form-control-position">
                        <i class="icon-lock"></i>
                    </div>
                    <?php if($errors->has('password')): ?>
                        <label class="error"><?php echo e($errors->first('password')); ?></label>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-6">
                    <div class="icheck-material-primary">
                        <input type="checkbox" id="user-checkbox" name="remember" checked="" />
                        <label for="user-checkbox">Remember me</label>
                    </div>
                </div>
                <div class="form-group col-6 text-right">
                    <a href="<?php echo e(url('/admin/password/reset')); ?>">Reset Password</a>
                </div>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Sign In</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gtvmcmgwqds4/public_html/resources/views/admin/auth/login.blade.php ENDPATH**/ ?>