<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Nature Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('public/panel/style2.css')); ?>">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.3/dist/leaflet.css" integrity="sha256-kLaT2GOSpHechhsozzB+flnD+zUyjE2LlfWPgU04xyI=" crossorigin="" />

  </head>
  <body>
    <div class="main_body">
        <div class="top_header row">
            <h2 class="col-lg-6 col-md-12 page_heading d-flex blue_color ps-4 align-items-center">SUPER ADMIN CHANNEL</h2>
            <div class="col-lg-6 col-md-12 top_header_div justify-content-around align-items-center">
            <div class="dropdowns_top_header d-flex justify-content-around">
            
            </div>
            <div class="top_bar_last d-flex  w-100 align-items-center">
            
            <div class="user_image d-flex align-items-center top_bar_elements">
                <?php if(Auth::user()->image): ?>
                <?php $image = asset('public/images/'.Auth::user()->image); ?>
                <img src="<?php echo e($image); ?>" alt="" class="user_image me-2 img-circle">
                <?php else: ?>
                <img src="<?php echo e(asset('public/images/User-Avatar.png')); ?>" alt="" class="user_image me-2 img-circle">
                <?php endif; ?>
                <p><?php echo e(Auth::user()->name); ?></p>
            </div>
            <div class="sign_out_btn top_bar_elements">
                <a href="<?php echo e(url('/admin/logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="btn btn-outline-secondary px-2">
                    Sign Out
                </a>
                <form id="logout-form" action="<?php echo e(url('/admin/logout')); ?>" method="POST" style="display: none;">
                    <?php echo e(csrf_field()); ?>

                </form>
            </div>
            </div>
        </div>
        <div class="sub_header row justify-content-between p-2 align-items-center">
            <div class="bussiness_name col-lg-4 col-md-12 ps-3">
                <h4><?php echo e(Auth::user()->name); ?></h4>
            </div>
            <div class="sub_header_last justify-content-around pe-3 col-md-12 col-lg-6">
                
            </div>
        </div>
    </div>
    <div class="search-container2 p-2">
        <input type="text" placeholder="Search...">
        <span class="">
            <img  id="search-btn2" src="<?php echo e(asset('public/panel/images/downcaret.png')); ?>" class="drop_icon" alt="">
        </span>
    </div>
    <div class="first_main_div2 p-4 m-auto">
        <div class="row ">
            <div class="col-xl-2 col-lg-12 col-md-12">
                <ul class="no_decoration_list list">
                    <?php if(has_permission(Auth::user()->role_id,'vendor','read')): ?>
                    <li class="mt-2 li_elements mb-2 <?php echo e((request()->is('admin/supplier') or request()->is('admin/supplier/*')) ? 'active' : ''); ?>"><img src="<?php echo e(asset('public/panel/images/Supplier.png')); ?>" class="me-2" width="30px" height="30px" alt="">
                        <a class="links" href="<?php echo e(url('admin/supplier')); ?>">Suppliers </a>
                    </li>
                    <?php endif; ?>
                    <?php if(has_permission(Auth::user()->role_id,'products','read') || has_permission(Auth::user()->role_id,'brand','read') || has_permission(Auth::user()->role_id,'categories','read') || has_permission(Auth::user()->role_id,'attributes','read') || has_permission(Auth::user()->role_id,'discount_offers','read')|| has_permission(Auth::user()->role_id,'product_reviews','read') ): ?>
                    <li class="mt-2 li_elements mb-2 <?php echo e((request()->is('admin/w2b_products/*')) ? 'active menu-open' : ''); ?>"> <img src="<?php echo e(asset('public/panel/images/icon8_wholesale.png')); ?>" class="me-2" width="30px" height="30px" alt="">
                        <a class="links" href="<?php echo e(url('admin/w2b_products')); ?>">Wholesale2b </a>
                    </li>
                    <?php endif; ?>
                    <?php if(has_permission(Auth::user()->role_id,'vendor','read')): ?>
                    <li class="mt-2 li_elements mb-2 <?php echo e((request()->is('admin/supplier') or request()->is('admin/supplier/*')) ? 'active' : ''); ?>"><img src="<?php echo e(asset('public/panel/images/icon8_adv.png')); ?>" class="me-2" width="30px" height="30px" alt="">
                        <a class="links" href="#">Advertising Promotions </a>
                    </li>
                    <?php endif; ?>
                    <?php if(has_permission(Auth::user()->role_id,'vendor','read')): ?>
                    <li class="mt-2 li_elements mb-2 <?php echo e((request()->is('admin/supplier') or request()->is('admin/supplier/*')) ? 'active' : ''); ?>"><img src="<?php echo e(asset('public/panel/images/icon8_shipping.png')); ?>" class="me-2" width="30px" height="30px" alt="">
                        <a class="links" href="#">Fullfilment Center </a>
                    </li>
                    <?php endif; ?>
                    <?php if(has_permission(Auth::user()->role_id,'vendor','read')): ?>
                    <li class="mt-2 li_elements mb-2 <?php echo e((request()->is('admin/vendor') or request()->is('admin/vendor/*')) ? 'active' : ''); ?>"><img src="<?php echo e(asset('public/panel/images/best_seller.png')); ?>" class="me-2" width="30px" height="30px" alt="">
                        <a class="links" href="<?php echo e(url('admin/vendor')); ?>">Sellers </a>
                    </li>
                    <?php endif; ?>
                    <?php if(has_permission(Auth::user()->role_id,'vendor','read')): ?>
                    <li class="mt-2 li_elements mb-2 <?php echo e((request()->is('admin/supplier') or request()->is('admin/supplier/*')) ? 'active' : ''); ?>"><img src="<?php echo e(asset('public/panel/images/icon8_general2.png')); ?>" class="me-2" width="30px" height="30px" alt="">
                        <a class="links" href="#">General </a>
                    </li>
                    <?php endif; ?>
                    <?php if(has_permission(Auth::user()->role_id,'vendor','read')): ?>
                    <li class="mt-2 li_elements mb-2 <?php echo e((request()->is('admin/supplier') or request()->is('admin/supplier/*')) ? 'active' : ''); ?>"><img src="<?php echo e(asset('public/panel/images/Management.png')); ?>" class="me-2" width="30px" height="30px" alt="">
                        <a class="links" href="#">Fund Management </a>
                    </li>
                    <?php endif; ?>
                    <?php if(has_permission(Auth::user()->role_id,'vendor','read')): ?>
                    <li class="mt-2 li_elements mb-2 <?php echo e((request()->is('admin/supplier') or request()->is('admin/supplier/*')) ? 'active' : ''); ?>"><img src="<?php echo e(asset('public/panel/images/Shipped.png')); ?>" class="me-2" width="30px" height="30px" alt="">
                        <a class="links" href="#">Shipping </a>
                    </li>
                    <?php endif; ?>
                    <?php if(has_permission(Auth::user()->role_id,'vendor','read')): ?>
                    <li class="mt-2 li_elements mb-2 <?php echo e((request()->is('admin/supplier') or request()->is('admin/supplier/*')) ? 'active' : ''); ?>"><img src="<?php echo e(asset('public/panel/images/graph_report.png')); ?>" class="me-2" width="30px" height="30px" alt="">
                        <a class="links" href="#">Reports </a>
                    </li>
                    <?php endif; ?>
                    
                </ul>
            </div>
            <div class="first_column col-xl-3 col-lg-12 col-md-12">
                <h5 class="headings"><img src="<?php echo e(asset('public/panel/images/Supplier.png')); ?>" width="30px" height="30px" alt="" class="me-2">Supplier</h5>
                <ul class="no_decoration_list">
                    
                    <?php if(has_permission(Auth::user()->role_id,'vendor','read') || has_permission(Auth::user()->role_id,'vendor_store','read') || has_permission(Auth::user()->role_id,'vendor_configuration','read') || has_permission(Auth::user()->role_id,'vendor_coupons','read') || has_permission(Auth::user()->role_id,'vendor_coupons_used','read') ): ?>
                    <li class="mt-2 underlined <?php echo e((request()->is('admin/supplier/*') or request()->is('admin/supplier_store/*') or request()->is('admin/supplier_configuration/*') or request()->is('admin/supplier_coupons/*') or request()->is('admin/supplier_coupons_used/*') or request()->is('admin/supplier_unverified_coupons/*')) ? 'active menu-open' : ''); ?>">
                        <div class="accordion" id="accordionExample">
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                                    Manage Suppliers Details
                                </button>
                            </h2>
                            <div id="collapseOne" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <ul class='no_decoration_list'>
                                        <?php if(has_permission(Auth::user()->role_id,'vendor','read')): ?>
                                        <li class="mt-2 underlined <?php echo e((request()->is('admin/supplier') or request()->is('admin/supplier/*')) ? 'active' : ''); ?>">
                                            <a href='<?php echo e(url('admin/supplier')); ?>' class='links'>Manage Suppliers</a>
                                        </li>
                                        <?php endif; ?>
                                        <?php if(has_permission(Auth::user()->role_id,'vendor','read')): ?>
                                            <li class="mt-2 underlined <?php echo e((request()->is('admin/supplier_category') or request()->is('admin/supplier_category/*')) ? 'active' : ''); ?>">
                                                <a href="<?php echo e(url('admin/supplier_category')); ?>" class="waves-effect links">
                                                    Manage Categories
                                                </a>
                                            </li>
                                        <?php endif; ?>
                                        
                                    </ul>
                            </div>
                        </div>
                        </div>
                    </li>
                    <?php if(has_permission(Auth::user()->role_id,'admin_roles','read')): ?>
                    <li class="mt-2 underlined <?php echo e((request()->is('admin/admin_roles') or request()->is('admin/admin_roles/*')) ? 'active' : ''); ?>">
                        <a href='<?php echo e(url('admin/admin_roles')); ?>' class='links'>Roles and Management</a>
                    </li>
                    <?php endif; ?>
                    <?php if(has_permission(Auth::user()->role_id,'products','read')): ?>
                    <li class="mt-2 underlined <?php echo e((request()->is('admin/products') or (request()->is('admin/products/*') && !request()->is('admin/products/inventory') && !request()->is('admin/products/generate-barcodes'))) ? 'active' : ''); ?>">
                        <a href='<?php echo e(url('admin/products')); ?>' class='links'>Product Management</a>
                    </li>
                    <?php endif; ?>
                    
                    <li class="mt-2 underlined"><a href='#' class='links'>Fulfillment Reports</a></li>
                    <?php endif; ?>
                </ul>
                <h5 class="headings"><img src="<?php echo e(asset('public/panel/images/icon8_wholesale.png')); ?>" width="30px" height="30px" alt="" class="me-2">Wholesale 2 B</h5>
                <ul class="no_decoration_list">
                    

                    
                    <?php if(has_permission(Auth::user()->role_id,'products','read')): ?>
                        <li class="mt-2 underlined <?php echo e((request()->is('admin/w2b_products') ) ? 'active' : ''); ?>">
                            <a href="<?php echo e(url('admin/w2b_products')); ?>" class="waves-effect links">
                                Manage Products
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if(has_permission(Auth::user()->role_id,'products','read')): ?>
                        <li class="mt-2 underlined <?php echo e((request()->is('admin/w2b_products') ) ? 'active' : ''); ?>">
                            <a href="<?php echo e(url('admin/w2b_products/orders')); ?>" class="waves-effect links">
                                Manage Orders
                            </a>
                        </li>
					<?php endif; ?>

                </ul>
                <h5 class="headings"><img src="<?php echo e(asset('public/panel/images/icon8_adv.png')); ?>" width="30px" height="30px" alt="" class="me-2">Advertising/Promotion</h5>
                <ul class="no_decoration_list">
                    <li class="mt-2 underlined">Create Campaign</li>
                    <li class="mt-2 underlined">Advertising Management</li>
                    <li class="mt-2 underlined">Coupon Setup/Edit</li>
                    <li class="mt-2 underlined">Safety/Security</li>
                    <li class="mt-2 underlined">Email Campaign</li>
                    <li class="mt-2 underlined">Hire Influencer</li>
                </ul>
            </div>
            <div class="second_column col-xl-3 col-lg-12 col-md-12">
                <h5 class="headings">Transaction By Customer</h5>
                <div>
                    <canvas style="height: 200px;" id="myChart"></canvas>
                </div>
                <h5 class="headings"><img src="<?php echo e(asset('public/panel/images/icon8_shipping.png')); ?>" width="30px" height="30px" alt="" class="me-2">Fulfillment Center</h5>
                <ul class="no_decoration_list">
                    <li class="mt-2 underlined">Fulfillment Setup/Edits</li>
                    <li class="mt-2 underlined">Fulfillment Management</li>
                    <li class="mt-2 underlined">Dropshipping</li>
                    <li class="mt-2 underlined">Inventory Management</li>
                    <li class="mt-2 underlined">Returns/Cancellations</li>
                </ul>
                <h5 class="headings"><img src="<?php echo e(asset('public/panel/images/best_seller.png')); ?>" width="30px" height="30px" alt="" class="me-2">Seller</h5>
                <ul class="no_decoration_list">
                    <?php if(has_permission(Auth::user()->role_id,'vendor','read') || has_permission(Auth::user()->role_id,'vendor_store','read') || has_permission(Auth::user()->role_id,'vendor_configuration','read') || has_permission(Auth::user()->role_id,'vendor_coupons','read') || has_permission(Auth::user()->role_id,'vendor_coupons_used','read') ): ?>
                    <li class="mt-2 underlined <?php echo e((request()->is('admin/vendor/*') or request()->is('admin/vendor_store/*') or request()->is('admin/vendor_configuration/*') or request()->is('admin/vendor_coupons/*') or request()->is('admin/vendor_coupons_used/*') or request()->is('admin/vendor_unverified_coupons/*')) ? 'active menu-open' : ''); ?>">
                        <div class="accordion" id="accordionExample">
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseOne">
                                    Manage Seller Details
                                </button>
                            </h2>
                            <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <ul class='no_decoration_list'>
                                        <?php if(has_permission(Auth::user()->role_id,'vendor','read')): ?>
                                        <li class="mt-2 underlined <?php echo e((request()->is('admin/vendor') or request()->is('admin/vendor/*')) ? 'active' : ''); ?>">
                                            <a href="<?php echo e(url('admin/vendor')); ?>" class="waves-effect links">
                                                Manage Sellers
                                            </a>
                                        </li>
                                        <?php endif; ?>
                                        <?php if(has_permission(Auth::user()->role_id,'vendor_store','read')): ?>
                                        <li class="mt-2 underlined <?php echo e((request()->is('admin/vendor_store') or request()->is('admin/vendor_store/*')) ? 'active' : ''); ?>">
                                            <a href="<?php echo e(url('admin/vendor_store')); ?>" class="waves-effect links">
                                                Manage Seller Stores
                                            </a>
                                        </li>
                                        <?php endif; ?>
                                        <?php /* ?>
                                        <li class="<?php echo e((request()->is('admin/vendor_configuration') or request()->is('admin/vendor_configuration/*')) ? 'active' : ''); ?>">
                                            <a href="<?php echo e(url('admin/vendor_configuration')); ?>" class="waves-effect">
                                                <i class="zmdi zmdi-dot-circle-alt"></i>Manage Configurations
                                            </a>
                                        </li>
                                        <?php */ ?>
                                        <?php if(has_permission(Auth::user()->role_id,'vendor_coupons','read')): ?>
                                        <li class="mt-2 underlined <?php echo e((request()->is('admin/vendor_coupons') or request()->is('admin/vendor_coupons/*')) ? 'active' : ''); ?>">
                                            <a href="<?php echo e(url('admin/vendor_coupons')); ?>" class="waves-effect links">
                                                Manage Verified Coupons
                                            </a>
                                        </li>
                                        <li class="mt-2 underlined <?php echo e((request()->is('admin/vendor_coupons') or request()->is('admin/vendor_coupons/*')) ? 'active' : ''); ?>">
                                            <a href="<?php echo e(url('admin/vendor_coupons/unverified')); ?>" class="waves-effect links">
                                                Manage Unverified Coupons
                                            </a>
                                        </li>
                                        <?php endif; ?>
                                        <!-- <li class="<?php echo e((request()->is('admin/vendor_coupons_used') or request()->is('admin/vendor_coupons_used/*')) ? 'active' : ''); ?>">
                                            <a href="<?php echo e(url('admin/vendor_coupons_used')); ?>" class="waves-effect">
                                                <i class="zmdi zmdi-dot-circle-alt"></i>Manage Used Coupons
                                            </a>
                                        </li> -->
                                        <!-- <li class="<?php echo e((request()->is('admin/vendor_payment') or request()->is('admin/vendor_payment/*')) ? 'active' : ''); ?>">
                                            <a href="<?php echo e(url('admin/vendor_payment')); ?>" class="waves-effect">
                                                <i class="zmdi zmdi-dot-circle-alt"></i>Manage Accounting
                                            </a>
                                        </li> -->
                                    </ul>
                            </div>
                        </div>
                        </div>
                    </li>
                    
                    <?php endif; ?>
                </ul>
            </div>
            <div class="third_column col-xl-4 col-lg-12 col-md-12">
                <h5 class="headings">Sales By Customer</h5>
                <div>
                    <canvas style="height: 200px;" id="myChart2"></canvas>
                </div>
                <div id="map" class="my-2" style="height: 200px;"></div>
                <div class="double_column justify-content-between">
                    <div>
                        <h5 class="headings"><img src="<?php echo e(asset('public/panel/images/icon8_general2.png')); ?>" width="30px" height="30px" alt="" class="me-2">General</h5>
                    <ul class="no_decoration_list">
                        <?php if(has_permission(Auth::user()->role_id,'admins','read')): ?>
                        <li class="mt-2 underlined <?php echo e((request()->is('admin/admins') or request()->is('admin/admins/*')) ? 'active' : ''); ?>">
                            <a class="links" href="<?php echo e(url('admin/admins')); ?>">All Admins</a>
                        </li>
                        <?php endif; ?>
                        <li class="mt-2 underlined">
                            <a class="links" href="<?php echo e(url('/admin/profile')); ?>">My Profile</a>
                        </li>
                        <?php if(has_permission(Auth::user()->role_id,'membership','read')): ?>
                        <li class="mt-2 underlined <?php echo e((request()->is('admin/membership/list/vendor')) ? 'active' : ''); ?>">
                            <a class="links" href="<?php echo e(url('admin/membership/list/vendor')); ?>">Vendor Membership</a>
                        </li>
                        <li class="mt-2 underlined <?php echo e((request()->is('admin/membership/list/supplier')) ? 'active' : ''); ?>">
                            <a class="links" href="<?php echo e(url('admin/membership/list/supplier')); ?>">Supplier Membership</a>
                        </li>
                        <li class="mt-2 underlined <?php echo e((request()->is('admin/membership/list/supplier_ruti_fullfill')) ? 'active' : ''); ?>">
                            <a class="links" href="<?php echo e(url('admin/membership/list/supplier_ruti_fullfill')); ?>">Nature Fulfill Membership</a>
                        </li>
                        <?php endif; ?>
                        
                    </ul>
                    <h5 class="headings"><img src="<?php echo e(asset('public/panel/images/Management.png')); ?>" width="30px" height="30px" alt="" class="me-2">Fund Management</h5>
                    <ul class="no_decoration_list">
                    <li class="mt-2 underlined">Create/View Bank Details</li>
                    <li class="mt-2 underlined">Create/View/Add/Edit Card</li>
                    <li class="mt-2 underlined">Fund Disbursed</li>
                    <li class="mt-2 underlined">Fund Balance</li>
                    <li class="mt-2 underlined">EFT Returned Details</li>
                    </ul>
                    </div>
                    <div>
                    <h5 class="headings"><img src="<?php echo e(asset('public/panel/images/Shipped.png')); ?>" width="30px" height="30px" alt="" class="me-2">Help</h5>
                    <ul class="no_decoration_list">
                        <li class="mt-2 underlined">Manage Tickets</li>
                        <li class="mt-2 underlined">Sign In</li>
                        <li class="mt-2 underlined">Create Account</li>
                        <li class="mt-2 underlined">Guide/Support</li>
                        <li class="mt-2 underlined">Demo Video</li>
                        <li class="mt-2 underlined">Returns</li>
                    </ul>
                    <h5 class="headings"><img src="<?php echo e(asset('public/panel/images/graph_report.png')); ?>" width="30px" height="30px" alt="" class="me-2">Reports</h5>
                    <ul class="no_decoration_list">
                    <li class="mt-2 underlined">Top Selling Products</li>
                    <li class="mt-2 underlined">Sales</li>
                    <li class="mt-2 underlined">Transaction(Earning)</li>
                    <li class="mt-2 underlined">Transaction(Orders)</li>
                    <li class="mt-2 ms-4"><button class="btn btn-primary py-1 px-3">Archive</button></li>
                    </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://unpkg.com/leaflet@1.9.3/dist/leaflet.js" integrity="sha256-WBkoXOwTeyKclOHuWtc+i2uENFpDZ9YPdf5Hf+D7ewM=" crossorigin=""></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
   <script src="<?php echo e(asset('public/panel/app2.js')); ?>"></script>
   <script src="<?php echo e(asset('public/panel/app.js')); ?>"></script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\work\ruti\resources\views/admin/layout/main2.blade.php ENDPATH**/ ?>