<center>
	<img src="<?php echo e(asset('public/images/logo-icon-xx.png')); ?>" style="width:250px; height: auto;border: none; display: block; -ms-interpolation-mode: bicubic;">
</center>

<h1>Verify your login</h1>
<p>Below is your one time passcode</p>
<h3><?php echo e($otp); ?></h3>
<p>If you are having any issue with your account, please don't hesitate to contact us by replying to this mail.</p>
<p>Thanks! <br> RUTI Self Checkout</p><?php /**PATH /home/gtvmcmgwqds4/public_html/resources/views//vendor/auth/vendor_otp.blade.php ENDPATH**/ ?>