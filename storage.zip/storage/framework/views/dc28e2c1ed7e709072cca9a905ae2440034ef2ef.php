<?php $__env->startSection('content'); ?>



<!-- download start -->
<section id="download" class="download">
    <h2 class="heading">
        <h1><img style="width: 10%" src="<?php echo e(asset('public/wb/img/logo/thank-you.gif')); ?>" alt=""></h1>
        <h2>Thank You For Ordering</h2>
    </h2>
    <div class="container">
        <div class="row">
            <div class="offset-md-3 col-md-6">
                <?php if(isset($page_meta['downloads_description']) && $page_meta['downloads_description']!=''): ?>
                    <p><?php echo $page_meta['downloads_description']; ?></p>
                <?php else: ?>
                    <p>A faster way to online shopping with the hands-on in store shopping experience. A quick way to reach out and keep in touch – all on the Nature checkout App. The Nature checkout mobile app is available for iOS and Android devices.</p>
                <?php endif; ?>
                <ul class="banner-icon bni1 banner-icon-new">
                    <li class="apple">
                        <img src="<?php echo e(asset('public/frontend/image/ios_qrcode.png')); ?>" alt="">
                    </li>
                    <li>
                        <img src="<?php echo e(asset('public/frontend/image/android_qrcode.png')); ?>" alt="">
                    </li>
                </ul><br>
                <ul class="banner-icon bni2">
                    <li class="apple"><a href="<?php echo e(isset($page_meta['downloads_ios_app_link']) && $page_meta['downloads_ios_app_link']!='' ? $page_meta['downloads_ios_app_link'] : '#'); ?>" target="_blank"><i class="fa fa-apple"></i><p>ios</p></a></li>
                    <li><a href="<?php echo e(isset($page_meta['downloads_android_app_link']) && $page_meta['downloads_android_app_link']!='' ? $page_meta['downloads_android_app_link'] : '#'); ?>" target="_blank"><i class="fa fa-android"></i><p>Android</p></a></li>
                </ul>
            </div>
        </div>
    </div>
</section>
<!-- download end -->

<div style="clear:both;"></div>
<br>
<div class="product_area treew  mb-64">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="product_header">
                    <div class="section_title">
                       <h2>Products You Would Like</h2>
                    </div>
                    <div class="product_tab_btn">

                    </div>
                </div>
            </div>
        </div><br>
        <div class="product_container">
           <div class="row">
            <div class="col-lg-12 col-md-12">
                <div class="productbg_right_side">
                    <div class="product_container">
                        <div class="row">
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-3 col-sm-6" style="padding-bottom: 35px">
                                <article class="single_product">
                                    <figure>
                                        <div class="product_thumb">
                                            <a class="primary_img" href="<?php echo e(route('product-detail',$p->sku)); ?>"><img src="<?php echo e($p->large_image_url_250x250); ?>" alt=""></a>
                                            <a class="secondary_img" href="<?php echo e(route('product-detail',$p->sku)); ?>"><img src="<?php echo e($p->large_image_url_250x250); ?>" alt=""></a>
                                            <div class="label_product">
                                                <span class="label_sale">Sale</span>

                                            </div>
                                            <div class="action_links">
                                                <ul>
                                                    <li class="add_to_cart"><a href="<?php echo e(route('add.to.cart1', $p->sku)); ?>" title="Add to cart"><span class="lnr lnr-cart"></span></a></li>
                                                    
                                                    <?php if(Auth::guard('w2bcustomer')->user()): ?>
                                                    <li class="wishlist"><a href="<?php echo e(route('wb-wishlist', $p->sku)); ?>" title="Add to Wishlist"><span class="fa fa-heart"></span></a></li>
                                                    <?php endif; ?>
                                                 
                                                </ul>
                                            </div>
                                        </div>
                                        <figcaption class="product_content">
                                            <h4 class="product_name double-lines-ellipsis"><a href="<?php echo e(route('product-detail',$p->sku)); ?>"><?php echo e(Str::limit($p->title, 30)); ?></a></h4>
                                            <h5 class='text-left'><i class='fa fa-check'></i> In Stock</h5>
                                            <div class="price_box">
                                                <span class="current_price">$<?php echo e(number_format((float)$p->retail_price, 2, '.', '')); ?></span>
                                            </div>
                                            <button class='btn btn-primary rounded p-2 my-2 w-100'>Add to Cart</button>
                                            <h5 class='text-left'>SKU: 4563</h5>
                                        </figcaption>
                                    </figure>
                                </article>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>

                        </div>
                </div>
            </div>

            </div>
            <br><br>

        </div>
    </div>
</div>
<!--product area end-->




<?php $__env->stopSection(); ?>

<?php echo $__env->make('front_end.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\work\ruti\resources\views/front_end/thank-you.blade.php ENDPATH**/ ?>