<?php $__env->startSection('content'); ?>



<!--breadcrumbs area start-->
<div class="mt-70">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb_content">
                   <h3>Checkout</h3>
                    <ul>
                        <li><a href="#">home</a></li>
                        <li>Checkout</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!--breadcrumbs area end-->
<?php if($errors->any()): ?>
    <div class="alert alert-danger container">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<!--Checkout page section-->
<div class="Checkout_section mt-70">
   <div class="container">

        <div class="checkout_form">
            <form action="<?php echo e(route('post-checkout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-lg-6 main_parent_div mt-4 border col-md-6 p-0">

                        <h3 class='sections_coupons_header w-100'>Billing and Shipping Details</h3>
                        <div class="row p-3">
                            <?php if(!Auth::guard('w2bcustomer')->user()): ?>
                            <div class="col-lg-6 mb-20">
                                <label>First Name <span>*</span></label>
                                <input type="text" name="first_name" placeholder="Enter First Name">
                            </div>
                            <div class="col-lg-6 mb-20">
                                <label>Last Name  <span>*</span></label>
                                <input type="text" name="last_name" placeholder="Enter Last Name">
                            </div>
                            <div class="col-lg-6 mb-20">
                                <label>Phone<span>*</span></label>
                                <input type="number" name="mobile" placeholder="Enter Phone Number">

                            </div>
                             <div class="col-lg-6 mb-20">
                                <label> Email Address   <span>*</span></label>
                                  <input type="email" name="email" placeholder="Enter Email Address">

                            </div>
                            <?php endif; ?>

                            <div class="col-12 mb-20">
                                <label for="country">State <span>*</span></label>
                                <select class="select2" name="state" id="state_id2">
                                    <option value="0">Select State</option>
                                    <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($state->id); ?>"><?php echo e($state->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-12 mb-20">
                                
                                <select name="city" id="city_id2"   class="select2 city-class d-none">
                                </select>
                            </div><br>
                            <div class="col-12 mb-20">
                                <label>Zip Code  <span>*</span></label>
                                <input placeholder="Enter Zip Code" type="text" name="zip_code">
                            </div>
                            <div class="col-12 mb-20">
                                <label>Street address  <span>*</span></label>
                                <input placeholder="House number and street name" type="text" name="address">
                            </div>
                            <div class="col-12 mb-20">
                                <input placeholder="Apartment, suite, unit etc. (optional)" type="text" name="address2">
                            </div>


                            <?php if(!Auth::guard('w2bcustomer')->user()): ?>

                            <div class="col-12 mb-20">
                                <input id="account" type="checkbox" data-target="createp_account" />
                                <label for="account" data-toggle="collapse" data-target="#collapseOne" aria-controls="collapseOne">Create an account?</label>

                                <div id="collapseOne" class="collapse one" data-parent="#accordion">
                                    <div class="card-body1">
                                       <label> Account password   <span>*</span></label>
                                        <input placeholder="password" type="password" name="password">
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>

                            <div class="col-12">
                                <div class="order-notes">
                                     <label for="order_note">Order Notes</label>
                                    <textarea id="order_note" name="order_notes" placeholder="Notes about your order, e.g. special notes for delivery."></textarea>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-lg-6 col-md-6 mt-4">
                    <div class='mb-4 border main_parent_div'>
                       <h3 class='sections_coupons_header'>PROMOTION CODE</h3>
                       <div class='p-3'>
                           <div class='h6'>Only one code can be applied per order</div>
                           <div>
                               <input type="text" class='w-75' placeholder=''>
                               <button class='ml-0 apply_button'>APPLY</button>
                            </div>
                            <div>
                                <select name="" id="available_offers" class='mt-4'>
                                    <option value="">Show available offers</option>
                                    <option value="">abc</option>
                                    <option value="">xyz</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    

                        <div class="order_table table-responsive main_parent_div border">
                            <h3 class='sections_coupons_header'>Your order</h3>
                            <table>
                                <thead class='no_bg'>
                                    <tr>
                                        <th>Product</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $total = 0 ?>

                                    <?php if(session('cart')): ?>
                                    <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sku => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $total += $details['retail_price'] * $details['quantity'] ?>
                                    <?php $tax = ($details['sales_tax_pct'] / 100) * $total ?>
                                    <?php $total_price = $total + $details['shipping_price'] + $tax ?>
                                    <input type="hidden" value="<?php echo e($total_price); ?>" name="total_price">
                                    <tr>
                                        <td> <?php echo e(Str::limit($details['title'], 30)); ?> <strong> × <?php echo e($details['quantity']); ?></strong></td>
                                        <td> $<?php echo e(number_format((float)$details['retail_price'] * $details['quantity'], 2, '.', '')); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Cart Subtotal</th>
                                        <td>$<?php echo e(number_format((float)$total, 2, '.', '')); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Shipping</th>
                                        <td><strong>$<?php echo e(number_format((float)$details['shipping_price'], 2, '.', '')); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <th>Sales Tax</th>
                                        <td><strong>$<?php echo e(number_format((float)$tax, 2, '.', '')); ?></strong></td>
                                    </tr>
                                    <tr class="order_total">
                                        <th>Order Total</th>
                                        <td><strong>$<?php echo e(number_format((float)$total_price, 2, '.', '')); ?></strong></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                        <div class="payment_method">

                            
                            <div class='order_button'>
                                <button class='mt-2 w-100' type="submit">Proceed to Payment</button>
                            </div>
                        </div>
                    
                </div>
            </div>
        </form>
        </div>
    </div>
</div>
<!--Checkout page section end-->


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scriptss'); ?>
<script>
    $(document).ready(function() {
    $('#state_id2').on('change', function() {

       var state_id = $(this).val();
    //    var companyID = $("#company2_id").val();
    //    console.log(cityID);
       if(state_id) {
           $.ajax({
              //  url: '/state/'+stateID,
              url: "<?php echo e(url('/state_cities')); ?>/"+state_id,
               type: "GET",
               data : {"_token":"<?php echo e(csrf_token()); ?>"},
               dataType: "json",
               success:function(data) {
                   console.log(data);
                 if(data){
                   $('.city-class').removeClass('d-none');
                   $('#city_id2').empty();
                   $('#city_id2').focus;
                   $('#city_id2').append('<option value="">-- Select City --</option>');
                   $.each(data, function(key, value){
                   $('select[name="city"]').append('<option value="'+ value.id +'">' + value.name+'</option>');
               });
             }else{
               $('#city_id2').empty();
             }
             }
           });
       }else{
         $('#city_id2').empty();
       }
    });
    });
    </script>

<script>
    $(document).ready(function() {
        $(".select2").select2({
        placeholder: "-- Select City --"
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front_end.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\work\ruti\resources\views/front_end/checkout.blade.php ENDPATH**/ ?>