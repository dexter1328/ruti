<?php $__env->startSection('content'); ?>

<?php if(session()->get('success')): ?>
	<div class="alert alert-success alert-dismissible" role="alert">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<div class="alert-icon">
			<i class="fa fa-check"></i>
		</div>
		<div class="alert-message">
			<span><strong>Success!</strong> <?php echo e(session()->get('success')); ?></span>
		</div>
	</div>
<?php endif; ?>

<div class="row">
	<div class="col-lg-12">
		<div class="card">
			<div class="card-header">
				<div class="left"><!-- <i class="fa fa-address-book-o"></i> --><span>Edit Profile</span></div>
			</div>
			<div class="card-body">
            	<div class="container-fluid">
					<form id="signupForm" method="post" action="<?php echo e(url('admin/profile')); ?>" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
					<div class="form-group row">
						<label for="input-10" class="col-sm-2 col-form-label">Name<span class="text-danger">*</span></label>
						<div class="col-sm-4">
							<input type="text" class="form-control" id="input-10" name="name" placeholder="Enter Name" value="<?php echo e(old('name',$admin->name)); ?>">
							<?php if($errors->has('name')): ?>
								<span class="text-danger"><?php echo e($errors->first('name')); ?></span>
							<?php endif; ?>
						</div>
						<label for="input-11" class="col-sm-2 col-form-label">Email<span class="text-danger">*</span></label>
						<div class="col-sm-4">
							<input type="email" class="form-control" id="input-11" name="email" placeholder="Enter Email" value="<?php echo e(old('email',$admin->email)); ?>">
							<?php if($errors->has('email')): ?>
								<span class="text-danger"><?php echo e($errors->first('email')); ?></span>
							<?php endif; ?>
						</div>
					</div>
					<div class="form-group row">
						<label for="input-12" class="col-sm-2 col-form-label">Image</label>
						<div class="col-sm-4">
							<input type="file" class="form-control" id="input-8" name="image" value="<?php echo e(old('image')); ?>">
							<?php if($errors->has('image')): ?>
								<span class="text-danger"><?php echo e($errors->first('image')); ?></span>
							<?php endif; ?>
							<?php if($admin->image): ?>
								<?php $image = asset('public/images/'.$admin->image); ?>
								<br>
								<img class="img-responsive" id="imagePreview" src="<?php echo e($image); ?>" height="100" width="100">
							<?php endif; ?>
						</div>
					</div>
					<center>
						<div class="form-footer">
							<button type="submit" class="btn btn-success"><i class="fa fa-check-square-o"></i> SAVE</button>
						</div>
					</center>
				</form>
                </div>
			</div>
		</div>
	</div>
</div>
<!--End Row--> 

<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script> 

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\work\ruti\resources\views/admin/admin/profile.blade.php ENDPATH**/ ?>